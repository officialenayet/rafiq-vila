package com.rafiqvila.app.sms

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Opens the phone's native Messaging app with the recipient and text pre-filled.
 * The landlord must review and press Send. No SMS permission is used, and
 * opening the app does NOT prove that a message was sent or delivered.
 */
object SmsLauncher {
    fun buildIntent(phone: String, body: String): Intent {
        val uri = Uri.parse("smsto:" + Uri.encode(phone, "+") + "?body=" + Uri.encode(body))
        return Intent(Intent.ACTION_SENDTO, uri).apply { putExtra("sms_body", body) }
    }

    /** Returns null on success, or a Bangla error message. */
    fun open(context: Context, phone: String, body: String): String? {
        val intent = buildIntent(phone, body)
        if (intent.resolveActivity(context.packageManager) == null) {
            return "এই ফোনে কোনো মেসেজিং অ্যাপ পাওয়া যায়নি"
        }
        return try {
            context.startActivity(intent)
            null
        } catch (e: ActivityNotFoundException) {
            "মেসেজিং অ্যাপ খোলা যায়নি"
        }
    }
}
