package com.rafiqvila.app.backup

import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import com.rafiqvila.app.data.AppDatabase
import com.rafiqvila.app.data.AppError
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.OutputStream

class BackupManager(private val context: Context, private val db: AppDatabase) {

    private fun checkpoint() {
        db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").use { it.moveToFirst() }
    }

    /** Copies the complete database file to a location chosen with the Storage Access Framework. */
    suspend fun exportDatabase(uri: Uri) = withContext(Dispatchers.IO) {
        checkpoint()
        val file = context.getDatabasePath(AppDatabase.NAME)
        val out = context.contentResolver.openOutputStream(uri, "w") ?: throw AppError("ফাইল খোলা যায়নি")
        out.use { o -> file.inputStream().use { it.copyTo(o) } }
    }

    suspend fun writeText(uri: Uri, text: String) = withContext(Dispatchers.IO) {
        val out = context.contentResolver.openOutputStream(uri, "w") ?: throw AppError("ফাইল খোলা যায়নি")
        out.use { it.write(text.toByteArray(Charsets.UTF_8)) }
    }

    suspend fun writePdf(uri: Uri, lines: List<String>) = withContext(Dispatchers.IO) {
        val out = context.contentResolver.openOutputStream(uri, "w") ?: throw AppError("ফাইল খোলা যায়নি")
        out.use { buildPdf(it, lines) }
    }

    private fun buildPdf(out: OutputStream, lines: List<String>) {
        val doc = PdfDocument()
        val paint = Paint().apply { textSize = 11f; isAntiAlias = true }
        val w = 595; val h = 842; val margin = 36; val lh = 16
        var number = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, number).create())
        var y = margin + lh
        for (line in lines) {
            if (y > h - margin) {
                doc.finishPage(page)
                number++
                page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, number).create())
                y = margin + lh
            }
            page.canvas.drawText(line, margin.toFloat(), y.toFloat(), paint)
            y += lh
        }
        doc.finishPage(page)
        doc.writeTo(out)
        doc.close()
    }

    /** Checks that a file is a complete, intact backup made by this app version. */
    internal fun validate(file: File) {
        val header = ByteArray(16)
        file.inputStream().use { it.read(header) }
        if (String(header, Charsets.US_ASCII).trimEnd('\u0000') != "SQLite format 3") {
            throw AppError("এটি সঠিক ব্যাকআপ ফাইল নয়")
        }
        var sdb: SQLiteDatabase? = null
        try {
            sdb = SQLiteDatabase.openDatabase(file.path, null, SQLiteDatabase.OPEN_READONLY)
            if (sdb.version != AppDatabase.VERSION) throw AppError("ব্যাকআপটি এই অ্যাপ ভার্সনের সাথে মেলে না")
            val tables = sdb.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { c ->
                buildSet { while (c.moveToNext()) add(c.getString(0)) }
            }
            val required = listOf("properties", "rooms", "tenants", "rent_charges", "payments", "financial_adjustments")
            if (!tables.containsAll(required)) throw AppError("ব্যাকআপ ফাইলে প্রয়োজনীয় তথ্য নেই")
            sdb.rawQuery("PRAGMA integrity_check", null).use { c ->
                if (!c.moveToFirst() || c.getString(0) != "ok") throw AppError("ব্যাকআপ ফাইলটি নষ্ট")
            }
        } catch (e: AppError) {
            throw e
        } catch (e: Exception) {
            throw AppError("ব্যাকআপ ফাইল পড়া যায়নি")
        } finally {
            sdb?.close()
        }
    }

    /**
     * Validates the chosen file first, keeps a safety copy of the current data, replaces the
     * database and restarts the app. Current data is untouched if validation fails.
     */
    suspend fun restore(uri: Uri) = withContext(Dispatchers.IO) {
        val temp = File(context.cacheDir, "restore_candidate.db")
        val input = context.contentResolver.openInputStream(uri) ?: throw AppError("ফাইল পড়া যায়নি")
        input.use { i -> temp.outputStream().use { i.copyTo(it) } }
        try {
            validate(temp)
        } catch (e: AppError) {
            temp.delete()
            throw e
        }
        checkpoint()
        val dbFile = context.getDatabasePath(AppDatabase.NAME)
        dbFile.copyTo(File(context.filesDir, "pre_restore_backup.db"), overwrite = true)
        db.close()
        dbFile.delete()
        File(dbFile.path + "-wal").delete()
        File(dbFile.path + "-shm").delete()
        temp.copyTo(dbFile, overwrite = true)
        temp.delete()
        restartApp()
    }

    private fun restartApp() {
        val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)!!
            .apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK) }
        context.startActivity(intent)
        android.os.Process.killProcess(android.os.Process.myPid())
    }
}
