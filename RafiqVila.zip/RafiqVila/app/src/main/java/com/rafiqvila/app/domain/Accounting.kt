package com.rafiqvila.app.domain

import com.rafiqvila.app.data.FinancialAdjustmentEntity
import com.rafiqvila.app.data.PaymentEntity
import com.rafiqvila.app.data.PropertyEntity
import com.rafiqvila.app.data.RentChargeEntity
import com.rafiqvila.app.data.RoomEntity
import com.rafiqvila.app.data.TenantEntity

data class LedgerData(
    val properties: List<PropertyEntity> = emptyList(),
    val rooms: List<RoomEntity> = emptyList(),
    val tenants: List<TenantEntity> = emptyList(),
    val charges: List<RentChargeEntity> = emptyList(),
    val adjustments: List<FinancialAdjustmentEntity> = emptyList(),
    val payments: List<PaymentEntity> = emptyList()
)

/**
 * Ledger summary of one tenancy over a range of billing periods [from, to].
 * Balance sign convention: positive = due, zero = fully paid, negative = advance credit.
 *   closing = previous + rent + other charges - payments
 */
data class RangeSummary(
    val previousBalance: Long,
    val rentCharge: Long,
    val otherCharges: Long,
    val paid: Long,
    val hasActivity: Boolean
) {
    val payable: Long get() = previousBalance + rentCharge + otherCharges
    val closingBalance: Long get() = payable - paid
    val due: Long get() = Accounting.due(closingBalance)
    val advance: Long get() = Accounting.advance(closingBalance)
    val toCollect: Long get() = maxOf(payable, 0L)
}

data class Filter(val propertyId: Long? = null, val roomId: Long? = null, val tenantId: Long? = null)
data class TenancyRow(val tenant: TenantEntity, val room: RoomEntity?, val summary: RangeSummary)
data class RoomRow(val room: RoomEntity, val propertyName: String, val tenant: TenantEntity?, val summary: RangeSummary?)

data class Totals(
    val rentCharged: Long,
    val toCollect: Long,
    val collected: Long,
    val due: Long,
    val advance: Long,
    val totalRooms: Int,
    val occupiedRooms: Int,
    val emptyRooms: Int
)

data class DashboardResult(
    val totals: Totals,
    val rows: List<TenancyRow>,
    val roomRows: List<RoomRow>,
    val payments: List<PaymentEntity>
) {
    companion object {
        val EMPTY = DashboardResult(Totals(0, 0, 0, 0, 0, 0, 0, 0), emptyList(), emptyList(), emptyList())
    }
}

data class HistoryEntry(
    val period: Int,
    val summary: RangeSummary,
    val payments: List<PaymentEntity>,
    val adjustments: List<FinancialAdjustmentEntity>
)

object Accounting {
    fun due(balance: Long): Long = maxOf(balance, 0L)
    fun advance(balance: Long): Long = maxOf(-balance, 0L)

    /** Balance is always derived from the ledger rows - there is no stored balance to drift out of sync. */
    fun summarize(
        tenantId: Long,
        from: Int,
        to: Int,
        charges: List<RentChargeEntity>,
        adjustments: List<FinancialAdjustmentEntity>,
        payments: List<PaymentEntity>
    ): RangeSummary {
        val c = charges.filter { it.tenantId == tenantId && it.period <= to }
        val a = adjustments.filter { it.tenantId == tenantId && it.period <= to }
        val p = payments.filter { it.tenantId == tenantId && !it.voided && it.period <= to }
        val previous = c.filter { it.period < from }.sumOf { it.amount } +
            a.filter { it.period < from }.sumOf { it.amount } -
            p.filter { it.period < from }.sumOf { it.amount }
        return RangeSummary(
            previousBalance = previous,
            rentCharge = c.filter { it.period >= from }.sumOf { it.amount },
            otherCharges = a.filter { it.period >= from }.sumOf { it.amount },
            paid = p.filter { it.period >= from }.sumOf { it.amount },
            hasActivity = c.isNotEmpty() || a.isNotEmpty() || p.isNotEmpty()
        )
    }

    /** Total lifetime balance of a tenancy. */
    fun lifetimeBalance(
        tenantId: Long,
        charges: List<RentChargeEntity>,
        adjustments: List<FinancialAdjustmentEntity>,
        payments: List<PaymentEntity>
    ): Long = summarize(tenantId, 0, 999_999, charges, adjustments, payments).closingBalance

    /**
     * Periods that still need a rent charge. A tenancy is charged for every month it overlaps,
     * from its start month to its end month (or [throughPeriod] if still active). Months before
     * the start or after the end (vacant periods) are never charged.
     */
    fun periodsToCharge(startEpochDay: Long, endEpochDay: Long?, throughPeriod: Int, existing: Set<Int>): List<Int> {
        val first = Period.fromEpochDay(startEpochDay)
        var last = throughPeriod
        if (endEpochDay != null) last = minOf(last, Period.fromEpochDay(endEpochDay))
        val out = mutableListOf<Int>()
        var p = first
        while (p <= last) {
            if (p !in existing) out.add(p)
            p = Period.next(p)
        }
        return out
    }

    fun compute(data: LedgerData, filter: Filter, from: Int, to: Int): DashboardResult {
        val roomById = data.rooms.associateBy { it.id }
        val propName = data.properties.associate { it.id to it.name }
        val rooms = data.rooms.filter {
            it.active && (filter.propertyId == null || it.propertyId == filter.propertyId) &&
                (filter.roomId == null || it.id == filter.roomId)
        }
        val tenants = data.tenants.filter {
            (filter.propertyId == null || it.propertyId == filter.propertyId) &&
                (filter.roomId == null || it.roomId == filter.roomId) &&
                (filter.tenantId == null || it.id == filter.tenantId)
        }
        val chargesBy = data.charges.groupBy { it.tenantId }
        val adjBy = data.adjustments.groupBy { it.tenantId }
        val payBy = data.payments.groupBy { it.tenantId }

        val rows = tenants.mapNotNull { t ->
            val s = summarize(t.id, from, to, chargesBy[t.id].orEmpty(), adjBy[t.id].orEmpty(), payBy[t.id].orEmpty())
            if (s.hasActivity) TenancyRow(t, roomById[t.roomId], s) else null
        }
        val summaryByTenant = rows.associate { it.tenant.id to it.summary }
        val activeByRoom = data.tenants.filter { it.active }.associateBy { it.roomId }
        val roomRows = rooms.map { r ->
            val t = activeByRoom[r.id]
            RoomRow(r, propName[r.propertyId].orEmpty(), t, t?.let { summaryByTenant[it.id] })
        }
        val ids = tenants.map { it.id }.toSet()
        val payments = data.payments
            .filter { !it.voided && it.tenantId in ids && it.period in from..to }
            .sortedWith(compareByDescending<PaymentEntity> { it.paidEpochDay }.thenByDescending { it.id })

        val occupied = roomRows.count { it.tenant != null }
        val totals = Totals(
            rentCharged = rows.sumOf { it.summary.rentCharge },
            toCollect = rows.sumOf { it.summary.toCollect },
            collected = rows.sumOf { it.summary.paid },
            due = rows.sumOf { it.summary.due },
            advance = rows.sumOf { it.summary.advance },
            totalRooms = roomRows.size,
            occupiedRooms = occupied,
            emptyRooms = roomRows.size - occupied
        )
        return DashboardResult(totals, rows, roomRows, payments)
    }

    fun history(tenantId: Long, data: LedgerData): List<HistoryEntry> {
        val c = data.charges.filter { it.tenantId == tenantId }
        val a = data.adjustments.filter { it.tenantId == tenantId }
        val p = data.payments.filter { it.tenantId == tenantId }
        val periods = (c.map { it.period } + a.map { it.period } + p.map { it.period }).toSortedSet()
        return periods.map { per ->
            HistoryEntry(
                per,
                summarize(tenantId, per, per, c, a, p),
                p.filter { it.period == per }.sortedBy { it.id },
                a.filter { it.period == per }
            )
        }
    }
}
