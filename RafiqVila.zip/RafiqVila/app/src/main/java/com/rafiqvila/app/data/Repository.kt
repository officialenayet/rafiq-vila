package com.rafiqvila.app.data

import androidx.room.withTransaction
import com.rafiqvila.app.domain.Accounting
import com.rafiqvila.app.domain.Dhaka
import com.rafiqvila.app.domain.LedgerData
import com.rafiqvila.app.domain.PhoneValidator
import com.rafiqvila.app.domain.Period
import kotlinx.coroutines.flow.first

/** A validation problem that is safe to show to the user as-is. */
class AppError(message: String) : Exception(message)

data class SavedPayment(
    val paymentId: Long,
    val tenant: TenantEntity,
    val room: RoomEntity,
    val propertyName: String,
    val period: Int,
    val rent: Long,
    val paidNow: Long,
    val due: Long,
    val advance: Long
)

class Repository(private val db: AppDatabase) {
    private val propertyDao = db.propertyDao()
    private val roomDao = db.roomDao()
    private val tenantDao = db.tenantDao()
    private val ledgerDao = db.ledgerDao()

    val properties = propertyDao.observeAll()
    val rooms = roomDao.observeAll()
    val tenants = tenantDao.observeAll()
    val charges = ledgerDao.observeCharges()
    val adjustments = ledgerDao.observeAdjustments()
    val payments = ledgerDao.observePayments()

    private fun now() = System.currentTimeMillis()

    private suspend fun audit(action: String, type: String, id: Long, details: String) {
        ledgerDao.insertAudit(AuditLogEntity(timestamp = now(), action = action, entityType = type, entityId = id, details = details))
    }

    suspend fun snapshot(): LedgerData = LedgerData(
        properties.first(), rooms.first(), tenants.first(), charges.first(), adjustments.first(), payments.first()
    )

    // ---------- properties ----------
    suspend fun addProperty(name: String, address: String): Long {
        val n = name.trim()
        if (n.isEmpty()) throw AppError("বাড়ির নাম দিন")
        return db.withTransaction {
            val id = propertyDao.insert(PropertyEntity(name = n, address = address.trim()))
            audit("PROPERTY_ADDED", "property", id, n)
            id
        }
    }

    suspend fun updateProperty(id: Long, name: String, address: String) {
        val n = name.trim()
        if (n.isEmpty()) throw AppError("বাড়ির নাম দিন")
        db.withTransaction {
            val p = propertyDao.get(id) ?: throw AppError("বাড়ি পাওয়া যায়নি")
            propertyDao.update(p.copy(name = n, address = address.trim()))
            audit("PROPERTY_UPDATED", "property", id, "${p.name} -> $n")
        }
    }

    // ---------- rooms ----------
    suspend fun addRoom(propertyId: Long, number: String, rent: Long, notes: String): Long = db.withTransaction {
        val n = number.trim()
        if (n.isEmpty()) throw AppError("রুম নম্বর দিন")
        if (rent <= 0) throw AppError("মাসিক ভাড়া ০-এর বেশি হতে হবে")
        if (propertyDao.get(propertyId) == null) throw AppError("বাড়ি নির্বাচন করুন")
        if (roomDao.find(propertyId, n) != null) throw AppError("এই বাড়িতে এই রুম নম্বর আগেই আছে")
        val id = roomDao.insert(RoomEntity(propertyId = propertyId, number = n, monthlyRent = rent, notes = notes.trim()))
        audit("ROOM_ADDED", "room", id, "number=$n rent=$rent")
        id
    }

    /** Changing the rent only affects charges generated in the future; old charges keep their amount. */
    suspend fun updateRoom(roomId: Long, number: String, rent: Long, notes: String) {
        db.withTransaction {
            val old = roomDao.get(roomId) ?: throw AppError("রুম পাওয়া যায়নি")
            val n = number.trim()
            if (n.isEmpty()) throw AppError("রুম নম্বর দিন")
            if (rent <= 0) throw AppError("মাসিক ভাড়া ০-এর বেশি হতে হবে")
            val clash = roomDao.find(old.propertyId, n)
            if (clash != null && clash.id != roomId) throw AppError("এই বাড়িতে এই রুম নম্বর আগেই আছে")
            roomDao.update(old.copy(number = n, monthlyRent = rent, notes = notes.trim()))
            if (old.monthlyRent != rent) audit("ROOM_RENT_CHANGED", "room", roomId, "${old.monthlyRent} -> $rent")
        }
    }

    /** Soft removal: the room and all of its history stay in the database. */
    suspend fun deactivateRoom(roomId: Long) {
        db.withTransaction {
            val r = roomDao.get(roomId) ?: throw AppError("রুম পাওয়া যায়নি")
            if (tenantDao.activeForRoom(roomId) != null) throw AppError("রুমে ভাড়াটিয়া আছে। আগে রুম খালি করুন")
            roomDao.update(r.copy(active = false))
            audit("ROOM_DEACTIVATED", "room", roomId, r.number)
        }
    }

    // ---------- tenants ----------
    private fun phoneForSave(raw: String): String {
        if (raw.isBlank()) return ""
        return PhoneValidator.normalize(raw) ?: throw AppError("মোবাইল নম্বর সঠিক নয় (উদাহরণ: 01712345678)")
    }

    suspend fun addTenant(name: String, phone: String, roomId: Long, startEpochDay: Long, notes: String): Long {
        val id = db.withTransaction {
            val n = name.trim()
            if (n.isEmpty()) throw AppError("ভাড়াটিয়ার নাম দিন")
            val room = roomDao.get(roomId)?.takeIf { it.active } ?: throw AppError("রুম নির্বাচন করুন")
            if (tenantDao.activeForRoom(roomId) != null) throw AppError("এই রুমে আগে থেকেই ভাড়াটিয়া আছে")
            val tid = tenantDao.insert(
                TenantEntity(name = n, phone = phoneForSave(phone), propertyId = room.propertyId, roomId = roomId,
                    startEpochDay = startEpochDay, notes = notes.trim())
            )
            audit("TENANT_ADDED", "tenant", tid, "$n room=${room.number}")
            tid
        }
        ensureCharges()
        return id
    }

    suspend fun updateTenant(id: Long, name: String, phone: String, notes: String) {
        db.withTransaction {
            val t = tenantDao.get(id) ?: throw AppError("ভাড়াটিয়া পাওয়া যায়নি")
            val n = name.trim()
            if (n.isEmpty()) throw AppError("ভাড়াটিয়ার নাম দিন")
            tenantDao.update(t.copy(name = n, phone = phoneForSave(phone), notes = notes.trim()))
            audit("TENANT_UPDATED", "tenant", id, n)
        }
    }

    /** Saves a corrected phone number and returns it in normalized (+88...) form. */
    suspend fun updatePhone(tenantId: Long, phone: String): String {
        val normalized = PhoneValidator.normalize(phone) ?: throw AppError("মোবাইল নম্বর সঠিক নয় (উদাহরণ: 01712345678)")
        db.withTransaction {
            val t = tenantDao.get(tenantId) ?: throw AppError("ভাড়াটিয়া পাওয়া যায়নি")
            tenantDao.update(t.copy(phone = normalized))
            audit("TENANT_PHONE_UPDATED", "tenant", tenantId, "")
        }
        return normalized
    }

    suspend fun moveOut(tenantId: Long, endEpochDay: Long) {
        db.withTransaction {
            val t = tenantDao.get(tenantId) ?: throw AppError("ভাড়াটিয়া পাওয়া যায়নি")
            if (!t.active) throw AppError("ভাড়াটিয়া আগেই বের হয়ে গেছেন")
            if (endEpochDay < t.startEpochDay) throw AppError("শেষ তারিখ শুরুর তারিখের আগে হতে পারে না")
            generateCharges(Dhaka.currentPeriod())
            tenantDao.update(t.copy(active = false, endEpochDay = endEpochDay))
            audit("TENANT_MOVED_OUT", "tenant", tenantId, "end=$endEpochDay")
        }
    }

    /**
     * Moves a tenant to another room. The old tenancy is closed (its history and any balance stay with it)
     * and a new tenancy starts. The month of the move is charged to the OLD room; the new room is charged from
     * the following month. With [carryBalance] the old balance (due or advance) is transferred by two
     * offsetting adjustments, so the total is unchanged.
     */
    suspend fun changeRoom(tenantId: Long, newRoomId: Long, dayEpoch: Long, carryBalance: Boolean): Long {
        val newId = db.withTransaction {
            val old = tenantDao.get(tenantId) ?: throw AppError("ভাড়াটিয়া পাওয়া যায়নি")
            if (!old.active) throw AppError("এই ভাড়াটিয়া এখন সক্রিয় নন")
            if (dayEpoch < old.startEpochDay) throw AppError("তারিখ শুরুর তারিখের আগে হতে পারে না")
            if (dayEpoch > Dhaka.todayEpochDay()) throw AppError("তারিখ আজকের পরে হতে পারে না")
            val room = roomDao.get(newRoomId)?.takeIf { it.active } ?: throw AppError("নতুন রুম নির্বাচন করুন")
            if (room.id == old.roomId) throw AppError("নতুন রুম আলাদা হতে হবে")
            if (tenantDao.activeForRoom(newRoomId) != null) throw AppError("নতুন রুমে আগে থেকেই ভাড়াটিয়া আছে")
            generateCharges(Dhaka.currentPeriod())
            tenantDao.update(old.copy(active = false, endEpochDay = dayEpoch))
            val nid = tenantDao.insert(
                TenantEntity(name = old.name, phone = old.phone, propertyId = room.propertyId, roomId = room.id,
                    startEpochDay = dayEpoch, notes = old.notes)
            )
            val period = Period.fromEpochDay(dayEpoch)
            // Zero placeholder: the move month is already charged to the old room.
            ledgerDao.insertCharge(RentChargeEntity(tenantId = nid, period = period, amount = 0, createdAt = now()))
            if (carryBalance) {
                val bal = Accounting.lifetimeBalance(old.id, ledgerDao.chargesFor(old.id), ledgerDao.adjustmentsFor(old.id), ledgerDao.paymentsFor(old.id))
                if (bal != 0L) {
                    val reason = "রুম পরিবর্তন: হিসাব স্থানান্তর"
                    ledgerDao.insertAdjustment(FinancialAdjustmentEntity(tenantId = old.id, period = period, amount = -bal, reason = reason, createdAt = now()))
                    ledgerDao.insertAdjustment(FinancialAdjustmentEntity(tenantId = nid, period = period, amount = bal, reason = reason, createdAt = now()))
                }
            }
            audit("ROOM_CHANGED", "tenant", nid, "from tenancy ${old.id} to room ${room.number}, carry=$carryBalance")
            nid
        }
        ensureCharges()
        return newId
    }

    // ---------- rent charges ----------
    private suspend fun generateCharges(through: Int) {
        for (t in tenantDao.all()) {
            val existing = ledgerDao.chargesFor(t.id).map { it.period }.toSet()
            val todo = Accounting.periodsToCharge(t.startEpochDay, t.endEpochDay, through, existing)
            if (todo.isEmpty()) continue
            val room = roomDao.get(t.roomId) ?: continue
            for (p in todo) {
                // Unique index (tenantId, period) + IGNORE makes this idempotent: no duplicate charges.
                ledgerDao.insertCharge(RentChargeEntity(tenantId = t.id, period = p, amount = room.monthlyRent, createdAt = now()))
            }
        }
    }

    /** Creates any missing monthly rent charges up to the current month (Asia/Dhaka). Safe to call repeatedly. */
    suspend fun ensureCharges() {
        db.withTransaction { generateCharges(Dhaka.currentPeriod()) }
    }

    // ---------- payments ----------
    suspend fun savePayment(tenantId: Long, period: Int, amount: Long, paidEpochDay: Long, note: String): SavedPayment =
        db.withTransaction {
            if (amount <= 0) throw AppError("টাকার পরিমাণ ০-এর বেশি হতে হবে")
            if (amount > 100_000_000) throw AppError("টাকার পরিমাণ অস্বাভাবিক বেশি")
            val tenant = tenantDao.get(tenantId) ?: throw AppError("ভাড়াটিয়া নির্বাচন করুন")
            if (period < Period.fromEpochDay(tenant.startEpochDay)) throw AppError("ভাড়াটিয়ার শুরুর মাসের আগের মাসে পেমেন্ট নেওয়া যাবে না")
            generateCharges(Dhaka.currentPeriod())
            val id = ledgerDao.insertPayment(
                PaymentEntity(tenantId = tenantId, period = period, amount = amount, paidEpochDay = paidEpochDay,
                    note = note.trim(), createdAt = now())
            )
            audit("PAYMENT_ADDED", "payment", id, "tenant=$tenantId period=$period amount=$amount")
            val room = roomDao.get(tenant.roomId) ?: throw AppError("রুম পাওয়া যায়নি")
            val prop = propertyDao.get(tenant.propertyId)
            val c = ledgerDao.chargesFor(tenantId)
            val s = Accounting.summarize(tenantId, period, period, c, ledgerDao.adjustmentsFor(tenantId), ledgerDao.paymentsFor(tenantId))
            val rent = c.firstOrNull { it.period == period }?.amount ?: room.monthlyRent
            SavedPayment(id, tenant, room, prop?.name.orEmpty(), period, rent, amount, s.due, s.advance)
        }

    /** Payments are never deleted: a correction marks the payment void (kept for the audit trail). */
    suspend fun voidPayment(paymentId: Long, reason: String) {
        db.withTransaction {
            if (reason.isBlank()) throw AppError("বাতিলের কারণ লিখুন")
            val p = ledgerDao.getPayment(paymentId) ?: throw AppError("পেমেন্ট পাওয়া যায়নি")
            if (p.voided) throw AppError("পেমেন্টটি আগেই বাতিল করা হয়েছে")
            ledgerDao.updatePayment(p.copy(voided = true, voidReason = reason.trim()))
            audit("PAYMENT_VOIDED", "payment", paymentId, "amount=${p.amount} reason=${reason.trim()}")
        }
    }

    /** Signed adjustment: positive = extra charge, negative = discount/refund correction. */
    suspend fun addAdjustment(tenantId: Long, period: Int, amount: Long, reason: String) {
        db.withTransaction {
            if (amount == 0L) throw AppError("পরিমাণ ০ হতে পারে না")
            if (reason.isBlank()) throw AppError("কারণ লিখুন")
            tenantDao.get(tenantId) ?: throw AppError("ভাড়াটিয়া পাওয়া যায়নি")
            val id = ledgerDao.insertAdjustment(FinancialAdjustmentEntity(tenantId = tenantId, period = period, amount = amount, reason = reason.trim(), createdAt = now()))
            audit("ADJUSTMENT_ADDED", "adjustment", id, "tenant=$tenantId period=$period amount=$amount reason=${reason.trim()}")
        }
    }

    /** Records only that the Messaging app was opened. Sending/delivery cannot be verified. */
    suspend fun markSmsOpened(paymentId: Long) {
        ledgerDao.getPayment(paymentId)?.let { ledgerDao.updatePayment(it.copy(smsStatus = 1)) }
    }

    // ---------- settings / audit ----------
    suspend fun lastBackup(): Long? = ledgerDao.getSetting("last_backup")?.toLongOrNull()
    suspend fun setLastBackup(millis: Long) = ledgerDao.putSetting(AppSettingsEntity("last_backup", millis.toString()))
    suspend fun recentAudit(limit: Int = 40) = ledgerDao.recentAudit(limit)
}
