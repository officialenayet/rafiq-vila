package com.rafiqvila.app.domain

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs

/** Billing period helpers. A period is an Int yyyymm, e.g. 202610. */
object Period {
    private val EN = listOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
    private val BN = listOf("জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর")

    fun of(year: Int, month: Int) = year * 100 + month
    fun year(p: Int) = p / 100
    fun month(p: Int) = p % 100
    fun next(p: Int) = if (month(p) == 12) of(year(p) + 1, 1) else p + 1
    fun prev(p: Int) = if (month(p) == 1) of(year(p) - 1, 12) else p - 1
    fun labelEn(p: Int) = "${EN[month(p) - 1]} ${year(p)}"
    fun labelBn(p: Int) = "${BN[month(p) - 1]} ${year(p)}"

    fun fromEpochDay(day: Long): Int {
        val d = LocalDate.ofEpochDay(day)
        return of(d.year, d.monthValue)
    }

    fun shift(p: Int, n: Int): Int {
        var x = p
        repeat(abs(n)) { x = if (n > 0) next(x) else prev(x) }
        return x
    }
}

/** All user-facing dates use the Asia/Dhaka time zone. */
object Dhaka {
    val zone: ZoneId = ZoneId.of("Asia/Dhaka")
    fun today(): LocalDate = LocalDate.now(zone)
    fun todayEpochDay(): Long = today().toEpochDay()
    fun currentPeriod(): Int = today().let { Period.of(it.year, it.monthValue) }
    fun formatDate(epochDay: Long): String =
        LocalDate.ofEpochDay(epochDay).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
    fun formatDateTime(millis: Long): String =
        Instant.ofEpochMilli(millis).atZone(zone).format(DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm a", Locale.US))
    fun fileStamp(): String =
        Instant.now().atZone(zone).format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm", Locale.US))
}
