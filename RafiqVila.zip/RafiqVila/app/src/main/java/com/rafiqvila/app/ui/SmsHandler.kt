package com.rafiqvila.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.rafiqvila.app.data.RoomEntity
import com.rafiqvila.app.data.TenantEntity
import com.rafiqvila.app.domain.*
import com.rafiqvila.app.sms.SmsLauncher

/** Ask to prepare an SMS for a tenancy at any time (not only right after a payment). */
data class SmsRequest(val tenant: TenantEntity, val room: RoomEntity, val period: Int)

/**
 * Builds the message from the CURRENT ledger for the chosen month (Paid = total received for that month so far),
 * then opens the native Messaging app. The landlord reviews and presses Send.
 */
@Composable
fun SmsRequestHandler(vm: MainViewModel, data: LedgerData, request: SmsRequest?, onFinished: () -> Unit) {
    if (request == null) return
    val context = LocalContext.current
    var needPhone by remember(request) { mutableStateOf(false) }

    fun send(phone: String) {
        val t = request.tenant
        val s = Accounting.summarize(t.id, request.period, request.period, data.charges, data.adjustments, data.payments)
        val rent = data.charges.firstOrNull { it.tenantId == t.id && it.period == request.period }?.amount ?: request.room.monthlyRent
        val body = SmsMessage.build(propName(data, request.room.propertyId), request.period, request.room.number, rent, s.paid, s.due, s.advance)
        val err = SmsLauncher.open(context, phone, body)
        if (err != null) vm.say(err)
        onFinished()
    }

    LaunchedEffect(request) {
        val raw = data.tenants.firstOrNull { it.id == request.tenant.id }?.phone ?: request.tenant.phone
        val phone = PhoneValidator.normalize(raw)
        if (phone == null) needPhone = true else send(phone)
    }

    if (needPhone) {
        var text by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = onFinished,
            title = { Text("মোবাইল নম্বর প্রয়োজন") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${request.tenant.name}-এর মোবাইল নম্বর নেই বা সঠিক নয়। সঠিক নম্বর দিন (উদাহরণ: 01712345678)।")
                    OutlinedTextField(
                        text, { text = it }, label = { Text("মোবাইল নম্বর") }, singleLine = true,
                        isError = err != null, supportingText = { err?.let { e -> Text(e) } },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.updatePhone(request.tenant.id, text, { err = it }) { normalized -> needPhone = false; send(normalized) } }) {
                    Text("সংরক্ষণ ও মেসেজ খুলুন")
                }
            },
            dismissButton = { TextButton(onClick = onFinished) { Text("বাতিল") } }
        )
    }
}
