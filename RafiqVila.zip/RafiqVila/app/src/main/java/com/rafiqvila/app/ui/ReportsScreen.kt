package com.rafiqvila.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rafiqvila.app.domain.*

@Composable
fun ReportsScreen(vm: MainViewModel) {
    val data by vm.data.collectAsStateWithLifecycle()
    val pid by vm.selectedProperty.collectAsStateWithLifecycle()
    val period by vm.period.collectAsStateWithLifecycle()
    var yearly by remember { mutableStateOf(false) }
    var roomId by remember { mutableStateOf<Long?>(null) }
    var tenantId by remember { mutableStateOf<Long?>(null) }

    val from = if (yearly) Period.of(Period.year(period), 1) else period
    val to = if (yearly) Period.of(Period.year(period), 12) else period
    val result = remember(data, pid, roomId, tenantId, from, to) { Accounting.compute(data, Filter(pid, roomId, tenantId), from, to) }
    val propNames = data.properties.associate { it.id to it.name }
    val title = (propNames[pid] ?: "সব বাড়ি") + " • " + if (yearly) "বছর ${Period.year(period)}" else Period.labelBn(period)

    val roomOptions: List<Pair<Long?, String>> = listOf<Pair<Long?, String>>(null to "সব রুম") +
        data.rooms.filter { it.active && (pid == null || it.propertyId == pid) }.map { it.id to "${propName(data, it.propertyId)} - ${it.number}" }
    val tenantOptions: List<Pair<Long?, String>> = listOf<Pair<Long?, String>>(null to "সব ভাড়াটিয়া") +
        data.tenants.filter { pid == null || it.propertyId == pid }.map { it.id to it.name + if (it.active) "" else " (সাবেক)" }

    val csvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri: Uri? ->
        if (uri != null) vm.exportText(uri, Exports.reportCsv(result, propNames))
    }
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri: Uri? ->
        if (uri != null) vm.exportPdf(uri, Exports.reportLines(title, result, propNames))
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        PropertyDropdown(data.properties, pid, { vm.selectedProperty.value = it; roomId = null; tenantId = null })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !yearly, onClick = { yearly = false }, label = { Text("মাসিক") })
            FilterChip(selected = yearly, onClick = { yearly = true }, label = { Text("বার্ষিক") })
        }
        PeriodSelector(period) { vm.period.value = it }
        DropdownSelector("রুম", roomOptions.firstOrNull { it.first == roomId }?.second ?: "সব রুম", roomOptions, { roomId = it }, Modifier.fillMaxWidth())
        DropdownSelector("ভাড়াটিয়া", tenantOptions.firstOrNull { it.first == tenantId }?.second ?: "সব ভাড়াটিয়া", tenantOptions, { tenantId = it }, Modifier.fillMaxWidth())

        val t = result.totals
        Card {
            Column(Modifier.padding(14.dp)) {
                Text(title, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                KV("মোট ভাড়া চার্জ", Money.taka(t.rentCharged))
                KV("মোট পাওনা", Money.taka(t.toCollect))
                KV("মোট আদায়", Money.taka(t.collected))
                KV("মোট বকেয়া", Money.taka(t.due), bold = true)
                KV("মোট অগ্রিম", Money.taka(t.advance), bold = true)
                KV("মোট রুম", t.totalRooms.toString())
                KV("ভাড়া দেওয়া রুম", t.occupiedRooms.toString())
                KV("খালি রুম", t.emptyRooms.toString())
            }
        }
        result.rows.forEach { r ->
            Card {
                Column(Modifier.padding(12.dp)) {
                    Text("${propNames[r.tenant.propertyId].orEmpty()} • রুম ${r.room?.number.orEmpty()} • ${r.tenant.name}", fontWeight = FontWeight.Bold)
                    KV("পাওনা", Money.taka(r.summary.toCollect))
                    KV("আদায়", Money.taka(r.summary.paid))
                    KV("বকেয়া / অগ্রিম", balanceText(r.summary.closingBalance))
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { csvLauncher.launch("rafiq_vila_report_${from}_${to}.csv") }, modifier = Modifier.weight(1f)) { Text("CSV") }
            Button(onClick = { pdfLauncher.launch("rafiq_vila_report_${from}_${to}.pdf") }, modifier = Modifier.weight(1f)) { Text("PDF") }
        }
    }
}
