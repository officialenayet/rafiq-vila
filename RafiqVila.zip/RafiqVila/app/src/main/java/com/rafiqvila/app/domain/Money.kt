package com.rafiqvila.app.domain

import kotlin.math.abs

/** Money is always whole Bangladeshi Taka stored in a Long. No floating point anywhere. */
object Money {
    /** Indian/Bangladeshi digit grouping: 12,34,567 */
    fun group(n: Long): String {
        val neg = n < 0
        val s = abs(n).toString()
        val sign = if (neg) "-" else ""
        if (s.length <= 3) return sign + s
        val last3 = s.takeLast(3)
        var rest = s.dropLast(3)
        val parts = mutableListOf<String>()
        while (rest.length > 2) {
            parts.add(0, rest.takeLast(2))
            rest = rest.dropLast(2)
        }
        if (rest.isNotEmpty()) parts.add(0, rest)
        return sign + parts.joinToString(",") + "," + last3
    }

    fun taka(n: Long): String = "৳" + group(n)

    fun toAscii(s: String): String = buildString {
        for (c in s) append(if (c in '০'..'৯') '0' + (c - '০') else c)
    }

    /** Parses digits (Latin or Bangla). Returns null when empty or unreasonably large. */
    fun parse(input: String): Long? {
        val d = toAscii(input).filter { it in '0'..'9' }
        if (d.isEmpty() || d.length > 10) return null
        return d.toLongOrNull()
    }
}
