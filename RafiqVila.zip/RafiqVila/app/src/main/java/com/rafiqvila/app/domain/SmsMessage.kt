package com.rafiqvila.app.domain

/** Bangladeshi mobile numbers: 01[3-9]xxxxxxxx, optionally prefixed by +88 / 88. */
object PhoneValidator {
    private val pattern = Regex("^01[3-9][0-9]{8}$")

    /** Returns the number in +8801XXXXXXXXX form, or null when invalid/missing. */
    fun normalize(raw: String): String? {
        var s = Money.toAscii(raw.trim()).replace(Regex("[\\s\\-()]"), "")
        s = when {
            s.startsWith("+880") -> "0" + s.removePrefix("+880")
            s.startsWith("880") -> "0" + s.removePrefix("880")
            else -> s
        }
        return if (pattern.matches(s)) "+88$s" else null
    }
}

object SmsMessage {
    fun build(
        propertyName: String,
        period: Int,
        roomNumber: String,
        monthlyRent: Long,
        paidNow: Long,
        remainingDue: Long,
        remainingAdvance: Long
    ): String =
        "$propertyName\n" +
            "Month: ${Period.labelEn(period)}\n" +
            "Room: $roomNumber\n" +
            "Rent: ${Money.taka(monthlyRent)}\n" +
            "Paid: ${Money.taka(paidNow)}\n" +
            "Due: ${Money.taka(remainingDue)}\n" +
            "Advance: ${Money.taka(remainingAdvance)}\n" +
            "\n" +
            "Thank you."
}
