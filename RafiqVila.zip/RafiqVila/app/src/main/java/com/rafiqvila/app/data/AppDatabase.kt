package com.rafiqvila.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        PropertyEntity::class, RoomEntity::class, TenantEntity::class,
        RentChargeEntity::class, PaymentEntity::class, FinancialAdjustmentEntity::class,
        AuditLogEntity::class, AppSettingsEntity::class
    ],
    version = AppDatabase.VERSION,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun propertyDao(): PropertyDao
    abstract fun roomDao(): RoomDao
    abstract fun tenantDao(): TenantDao
    abstract fun ledgerDao(): LedgerDao

    companion object {
        const val VERSION = 1
        const val NAME = "rafiq_vila.db"

        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: create(context, NAME).also { instance = it }
            }

        /** name == null creates an in-memory database (tests). */
        fun create(context: Context, name: String?): AppDatabase {
            val app = context.applicationContext
            val builder = if (name == null) {
                Room.inMemoryDatabaseBuilder(app, AppDatabase::class.java)
            } else {
                Room.databaseBuilder(app, AppDatabase::class.java, name)
            }
            // IMPORTANT: never use fallbackToDestructiveMigration(). Future schema
            // changes must ship with an explicit Migration so user data is kept.
            return builder.addCallback(seedCallback).build()
        }

        private val seedCallback = object : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                listOf("RAFIQ VILA 1", "RAFIQ VILA 2", "RAFIQ VILA 3").forEach {
                    db.execSQL("INSERT INTO properties (name, address, active) VALUES ('$it', '', 1)")
                }
            }
        }
    }
}
