package com.rafiqvila.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun RafiqTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF1B5E20),
            secondary = Color(0xFF00695C),
            primaryContainer = Color(0xFFC8E6C9)
        ),
        content = content
    )
}
