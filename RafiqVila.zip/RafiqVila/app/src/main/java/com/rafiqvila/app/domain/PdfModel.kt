package com.rafiqvila.app.domain

/** A simple, testable description of a PDF page flow. The Android renderer draws it. */
sealed class PdfBlock {
    data class Heading(val text: String, val size: Float = 16f) : PdfBlock()
    data class Line(val text: String, val bold: Boolean = false) : PdfBlock()
    object Gap : PdfBlock()

    /** A table with a coloured header row, optional bold total row, and right-aligned numeric columns. */
    data class Grid(
        val title: String?,
        val headerColor: Int,
        val headers: List<String>,
        val rows: List<List<String>>,
        val total: List<String>?,
        val weights: List<Float>,
        val numericCols: Set<Int>
    ) : PdfBlock()
}

object PdfColors {
    val DARK = 0xFF37474F.toInt()
    private val PALETTE = listOf(
        0xFF1B5E20.toInt(), // green
        0xFF1565C0.toInt(), // blue
        0xFFB71C1C.toInt(), // red
        0xFF6A1B9A.toInt(), // purple
        0xFFEF6C00.toInt(), // orange
        0xFF00695C.toInt()  // teal
    )
    fun forIndex(i: Int): Int = PALETTE[i % PALETTE.size]
}
