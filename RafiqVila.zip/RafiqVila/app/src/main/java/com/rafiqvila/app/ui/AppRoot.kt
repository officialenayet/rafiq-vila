package com.rafiqvila.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

private data class NavTab(val route: String, val label: String, val icon: ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }

    val tabs = listOf(
        NavTab("dashboard", "ড্যাশবোর্ড", Icons.Default.Home),
        NavTab("rent", "ভাড়া এন্ট্রি", Icons.Default.Add),
        NavTab("rooms", "রুম", Icons.Default.Menu),
        NavTab("tenants", "ভাড়াটিয়া", Icons.Default.Person),
        NavTab("reports", "রিপোর্ট", Icons.Default.Info)
    )
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val isMain = tabs.any { it.route == route }
    val title = when {
        route == null -> "RAFIQ VILA"
        route == "settings" -> "সেটিংস ও ব্যাকআপ"
        route.startsWith("history") -> "পেমেন্ট হিস্ট্রি"
        route.startsWith("list") -> when (entry?.arguments?.getString("type")) {
            "toCollect" -> "মোট পাওনা"
            "collected" -> "আদায় হয়েছে"
            "due" -> "মোট বকেয়া"
            "advance" -> "মোট অগ্রিম"
            "rooms" -> "মোট রুম"
            "occupied" -> "ভাড়া দেওয়া রুম"
            else -> "খালি রুম"
        }
        else -> tabs.firstOrNull { it.route == route }?.label ?: "RAFIQ VILA"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    if (!isMain) IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, contentDescription = "ফিরে যান") }
                },
                actions = {
                    if (route != "settings") IconButton(onClick = { nav.navigate("settings") }) {
                        Icon(Icons.Default.Settings, contentDescription = "সেটিংস")
                    }
                }
            )
        },
        bottomBar = {
            if (isMain) NavigationBar {
                tabs.forEach { t ->
                    NavigationBarItem(
                        selected = route == t.route,
                        onClick = {
                            nav.navigate(t.route) {
                                popUpTo("dashboard") { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(t.icon, contentDescription = null) },
                        label = { Text(t.label, fontSize = 10.sp, maxLines = 1) }
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snack) }
    ) { pad ->
        NavHost(nav, startDestination = "dashboard", modifier = Modifier.padding(pad)) {
            composable("dashboard") { DashboardScreen(vm, nav) }
            composable("rent") { RentEntryScreen(vm) }
            composable("rooms") { RoomsScreen(vm, nav) }
            composable("tenants") { TenantsScreen(vm, nav) }
            composable("reports") { ReportsScreen(vm) }
            composable("settings") { SettingsScreen(vm) }
            composable("list/{type}") { DrillDownScreen(vm, it.arguments?.getString("type") ?: "") }
            composable("history/{roomId}", arguments = listOf(navArgument("roomId") { type = NavType.LongType })) {
                HistoryScreen(vm, it.arguments?.getLong("roomId") ?: 0L)
            }
        }
    }
}
