package com.rafiqvila.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.rafiqvila.app.ui.AppRoot
import com.rafiqvila.app.ui.RafiqTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RafiqTheme { AppRoot() } }
    }
}
