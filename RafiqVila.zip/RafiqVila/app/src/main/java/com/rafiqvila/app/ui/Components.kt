package com.rafiqvila.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rafiqvila.app.data.*
import com.rafiqvila.app.domain.*

fun balanceText(b: Long): String = when {
    b > 0 -> "বকেয়া ${Money.taka(b)}"
    b < 0 -> "অগ্রিম ${Money.taka(-b)}"
    else -> "পরিশোধিত ${Money.taka(0)}"
}

fun propName(data: LedgerData, id: Long): String = data.properties.firstOrNull { it.id == id }?.name.orEmpty()

@Composable
fun <T> DropdownSelector(
    label: String,
    selectedText: String,
    options: List<Pair<T, String>>,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier
) {
    var open by remember { mutableStateOf(false) }
    Column(modifier) {
        if (label.isNotEmpty()) Text(label, style = MaterialTheme.typography.labelMedium)
        Box {
            OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selectedText, modifier = Modifier.weight(1f), maxLines = 1)
                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                options.forEach { (value, text) ->
                    DropdownMenuItem(text = { Text(text) }, onClick = { onSelect(value); open = false })
                }
            }
        }
    }
}

@Composable
fun PropertyDropdown(
    properties: List<PropertyEntity>,
    selectedId: Long?,
    onSelect: (Long?) -> Unit,
    includeAll: Boolean = true,
    label: String = "বাড়ি নির্বাচন",
    modifier: Modifier = Modifier
) {
    val options = mutableListOf<Pair<Long?, String>>()
    if (includeAll) options.add(null to "সব বাড়ি")
    properties.filter { it.active }.forEach { options.add(it.id to it.name) }
    val text = properties.firstOrNull { it.id == selectedId }?.name ?: if (includeAll) "সব বাড়ি" else "বাড়ি নির্বাচন করুন"
    DropdownSelector(label, text, options, onSelect, modifier.fillMaxWidth())
}

@Composable
fun PeriodSelector(period: Int, onChange: (Int) -> Unit, modifier: Modifier = Modifier) {
    val options = remember {
        val cur = Dhaka.currentPeriod()
        (-36..1).map { Period.shift(cur, it) }.reversed().map { it to Period.labelBn(it) }
    }
    Row(modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        IconButton(onClick = { onChange(Period.prev(period)) }) { Text("‹", fontSize = 28.sp) }
        DropdownSelector("", Period.labelBn(period), options, onChange, Modifier.weight(1f))
        IconButton(onClick = { onChange(Period.next(period)) }) { Text("›", fontSize = 28.sp) }
    }
}

@Composable
fun MoneyField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter { c -> c.isDigit() }.take(10)) },
        label = { Text(label) },
        prefix = { Text("৳") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun ConfirmDialog(title: String, text: String, confirmLabel: String = "নিশ্চিত", onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = { onConfirm(); onDismiss() }) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateField(label: String, epochDay: Long, onChange: (Long) -> Unit, modifier: Modifier = Modifier) {
    var show by remember { mutableStateOf(false) }
    OutlinedButton(onClick = { show = true }, modifier = modifier.fillMaxWidth()) {
        Text("$label: ${Dhaka.formatDate(epochDay)}")
    }
    if (show) {
        val state = rememberDatePickerState(initialSelectedDateMillis = epochDay * 86_400_000L)
        DatePickerDialog(
            onDismissRequest = { show = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { onChange(Math.floorDiv(it, 86_400_000L)) }
                    show = false
                }) { Text("ঠিক আছে") }
            },
            dismissButton = { TextButton(onClick = { show = false }) { Text("বাতিল") } }
        ) { DatePicker(state = state) }
    }
}

@Composable
fun StatCard(label: String, value: String, container: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = container)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(6.dp))
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun KV(label: String, value: String, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Text(value, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun EmptyNote(text: String) {
    Text(text, Modifier.padding(24.dp), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.outline)
}

@Composable
fun AdjustmentDialog(onDismiss: () -> Unit, onSubmit: (Long, String, (String) -> Unit) -> Unit) {
    var amount by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var negative by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("সমন্বয় / অন্যান্য চার্জ") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !negative, onClick = { negative = false }, label = { Text("অতিরিক্ত চার্জ") })
                    FilterChip(selected = negative, onClick = { negative = true }, label = { Text("ছাড়/কমানো") })
                }
                MoneyField(amount, { amount = it }, "পরিমাণ")
                OutlinedTextField(reason, { reason = it }, label = { Text("কারণ (আবশ্যক)") }, modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = Money.parse(amount)
                if (a == null || a == 0L) error = "সঠিক পরিমাণ লিখুন"
                else onSubmit(if (negative) -a else a, reason) { error = it }
            }) { Text("সংরক্ষণ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
fun RoomFormDialog(vm: MainViewModel, data: LedgerData, editing: RoomEntity?, defaultPropertyId: Long?, onDismiss: () -> Unit) {
    var propertyId by remember { mutableStateOf(editing?.propertyId ?: defaultPropertyId ?: data.properties.firstOrNull { it.active }?.id) }
    var number by remember { mutableStateOf(editing?.number ?: "") }
    var rent by remember { mutableStateOf(editing?.monthlyRent?.toString() ?: "") }
    var notes by remember { mutableStateOf(editing?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (editing == null) "নতুন রুম" else "রুম সম্পাদনা") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (editing == null) PropertyDropdown(data.properties, propertyId, { propertyId = it }, includeAll = false)
                OutlinedTextField(number, { number = it }, label = { Text("রুম নম্বর/নাম (যেমন 101)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                MoneyField(rent, { rent = it }, "মাসিক ভাড়া")
                if (editing != null) Text("ভাড়া বদলালে শুধু ভবিষ্যতের মাসে প্রযোজ্য হবে; আগের হিসাব অপরিবর্তিত থাকবে।", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(notes, { notes = it }, label = { Text("নোট (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val r = Money.parse(rent)
                val pid = propertyId
                if (r == null) error = "সঠিক ভাড়া লিখুন"
                else if (editing == null) {
                    if (pid == null) error = "বাড়ি নির্বাচন করুন" else vm.addRoom(pid, number, r, notes, onDismiss) { error = it }
                } else vm.updateRoom(editing.id, number, r, notes, onDismiss) { error = it }
            }) { Text("সংরক্ষণ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
fun TenantFormDialog(vm: MainViewModel, data: LedgerData, presetRoomId: Long?, editing: TenantEntity?, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(editing?.name ?: "") }
    var phone by remember { mutableStateOf(editing?.phone ?: "") }
    var notes by remember { mutableStateOf(editing?.notes ?: "") }
    var roomId by remember { mutableStateOf(presetRoomId) }
    var start by remember { mutableStateOf(editing?.startEpochDay ?: Dhaka.todayEpochDay()) }
    var error by remember { mutableStateOf<String?>(null) }
    val vacant = data.rooms.filter { r -> r.active && data.tenants.none { it.roomId == r.id && it.active } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (editing == null) "নতুন ভাড়াটিয়া" else "ভাড়াটিয়া সম্পাদনা") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("পূর্ণ নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    phone, { phone = it }, label = { Text("মোবাইল নম্বর (01XXXXXXXXX)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth()
                )
                if (editing == null) {
                    val sel = vacant.firstOrNull { it.id == roomId }
                    DropdownSelector(
                        "রুম", sel?.let { "${propName(data, it.propertyId)} - ${it.number}" } ?: "খালি রুম নির্বাচন করুন",
                        vacant.map { it.id to "${propName(data, it.propertyId)} - ${it.number}" }, { roomId = it }, Modifier.fillMaxWidth()
                    )
                    DateField("শুরুর তারিখ", start, { start = it })
                    Text("শুরুর মাস থেকে প্রতি মাসের ভাড়া স্বয়ংক্রিয়ভাবে যোগ হবে।", style = MaterialTheme.typography.bodySmall)
                }
                OutlinedTextField(notes, { notes = it }, label = { Text("নোট (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (editing == null) {
                    val rid = roomId
                    if (rid == null) error = "রুম নির্বাচন করুন" else vm.addTenant(name, phone, rid, start, notes, onDismiss) { error = it }
                } else vm.updateTenant(editing.id, name, phone, notes, onDismiss) { error = it }
            }) { Text("সংরক্ষণ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
fun ChangeRoomDialog(vm: MainViewModel, data: LedgerData, tenant: TenantEntity, onDismiss: () -> Unit) {
    var newRoom by remember { mutableStateOf<Long?>(null) }
    var day by remember { mutableStateOf(Dhaka.todayEpochDay()) }
    var carry by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val vacant = data.rooms.filter { r -> r.active && r.id != tenant.roomId && data.tenants.none { it.roomId == r.id && it.active } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("রুম পরিবর্তন: ${tenant.name}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val sel = vacant.firstOrNull { it.id == newRoom }
                DropdownSelector(
                    "নতুন রুম", sel?.let { "${propName(data, it.propertyId)} - ${it.number}" } ?: "খালি রুম নির্বাচন করুন",
                    vacant.map { it.id to "${propName(data, it.propertyId)} - ${it.number}" }, { newRoom = it }, Modifier.fillMaxWidth()
                )
                DateField("পরিবর্তনের তারিখ", day, { day = it })
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Checkbox(checked = carry, onCheckedChange = { carry = it })
                    Text("আগের বকেয়া/অগ্রিম নতুন রুমে নিয়ে যান", Modifier.weight(1f))
                }
                Text("পরিবর্তনের মাসের ভাড়া আগের রুমে ধরা হয়; নতুন রুমের ভাড়া পরের মাস থেকে শুরু।", style = MaterialTheme.typography.bodySmall)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val rid = newRoom
                if (rid == null) error = "নতুন রুম নির্বাচন করুন" else vm.changeRoom(tenant.id, rid, day, carry, onDismiss) { error = it }
            }) { Text("পরিবর্তন করুন") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}
