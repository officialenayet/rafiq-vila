package com.rafiqvila.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rafiqvila.app.data.PropertyEntity
import com.rafiqvila.app.domain.Dhaka

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val data by vm.data.collectAsStateWithLifecycle()
    val last by vm.lastBackup.collectAsStateWithLifecycle()
    val audit by vm.audit.collectAsStateWithLifecycle()
    var pendingRestore by remember { mutableStateOf<Uri?>(null) }
    var propDialog by remember { mutableStateOf<PropertyEntity?>(null) }
    var addProp by remember { mutableStateOf(false) }
    var showAudit by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.refreshLastBackup() }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri: Uri? ->
        if (uri != null) vm.exportBackup(uri)
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) pendingRestore = uri
    }
    val csvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri: Uri? ->
        if (uri != null) vm.exportLedgerCsv(uri)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("বাড়ি ব্যবস্থাপনা", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        data.properties.forEach { p ->
            Card {
                Row(Modifier.padding(start = 14.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.Bold)
                        if (p.address.isNotBlank()) Text(p.address, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton(onClick = { propDialog = p }) { Text("সম্পাদনা") }
                }
            }
        }
        OutlinedButton(onClick = { addProp = true }, modifier = Modifier.fillMaxWidth()) { Text("নতুন বাড়ি যোগ করুন") }

        HorizontalDivider()
        Text("ব্যাকআপ ও রিস্টোর", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(
            "শেষ ব্যাকআপ: " + (last?.let { Dhaka.formatDateTime(it) } ?: "এখনও নেওয়া হয়নি"),
            style = MaterialTheme.typography.bodyMedium
        )
        Text(
            "এই অ্যাপের সব তথ্য শুধু এই ফোনে থাকে; অন্য ফোনের সাথে নিজে নিজে সিঙ্ক হয় না। ফোন হারালে বা বদলালে ব্যাকআপ ছাড়া তথ্য ফিরে পাওয়া যাবে না। নিয়মিত ব্যাকআপ নিয়ে Google Drive বা অন্য নিরাপদ জায়গায় রাখুন।",
            style = MaterialTheme.typography.bodySmall
        )
        Button(onClick = { exportLauncher.launch("rafiq_vila_backup_${Dhaka.fileStamp()}.db") }, modifier = Modifier.fillMaxWidth()) {
            Text("সম্পূর্ণ ব্যাকআপ তৈরি করুন")
        }
        OutlinedButton(onClick = { restoreLauncher.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
            Text("ব্যাকআপ থেকে রিস্টোর করুন")
        }
        OutlinedButton(onClick = { csvLauncher.launch("rafiq_vila_ledger_${Dhaka.fileStamp()}.csv") }, modifier = Modifier.fillMaxWidth()) {
            Text("সব হিসাব CSV এক্সপোর্ট")
        }

        HorizontalDivider()
        OutlinedButton(onClick = { vm.loadAudit(); showAudit = true }, modifier = Modifier.fillMaxWidth()) { Text("অডিট লগ দেখুন") }
        Text("RAFIQ VILA v1.0.0 • অফলাইনে কাজ করে • সময়: Asia/Dhaka", style = MaterialTheme.typography.bodySmall)
    }

    if (addProp) PropertyDialog(vm, null) { addProp = false }
    propDialog?.let { p -> PropertyDialog(vm, p) { propDialog = null } }

    pendingRestore?.let { uri ->
        ConfirmDialog(
            "রিস্টোর করবেন?",
            "বর্তমান সব তথ্য ব্যাকআপ ফাইলের তথ্য দিয়ে বদলে যাবে (আগে একটি নিরাপত্তা কপি রাখা হবে)। ফাইল ঠিক থাকলে অ্যাপ নিজে আবার চালু হবে।",
            "রিস্টোর", { vm.restoreBackup(uri) }, { pendingRestore = null }
        )
    }
    if (showAudit) {
        AlertDialog(
            onDismissRequest = { showAudit = false },
            title = { Text("অডিট লগ (সর্বশেষ ৪০টি)") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    if (audit.isEmpty()) Text("কিছু নেই")
                    audit.forEach {
                        Text("${Dhaka.formatDateTime(it.timestamp)}\n${it.action} ${it.details}", style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(6.dp))
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showAudit = false }) { Text("বন্ধ") } }
        )
    }
}

@Composable
private fun PropertyDialog(vm: MainViewModel, editing: PropertyEntity?, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(editing?.name ?: "") }
    var address by remember { mutableStateOf(editing?.address ?: "") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (editing == null) "নতুন বাড়ি" else "বাড়ি সম্পাদনা") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("বাড়ির নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(address, { address = it }, label = { Text("ঠিকানা (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (editing == null) vm.addProperty(name, address, onDismiss) { error = it }
                else vm.updateProperty(editing.id, name, address, onDismiss) { error = it }
            }) { Text("সংরক্ষণ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}
