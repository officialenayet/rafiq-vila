package com.rafiqvila.app.backup

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.rafiqvila.app.domain.PdfBlock
import java.io.OutputStream

/** Draws [PdfBlock]s onto A4 pages: headings, text lines and coloured-header tables that continue across pages. */
class PdfRenderer {
    private val pageW = 595
    private val pageH = 842
    private val margin = 32f
    private val contentW = pageW - 2 * margin
    private val rowH = 20f

    private val doc = PdfDocument()
    private var pageNo = 0
    private lateinit var page: PdfDocument.Page
    private lateinit var canvas: Canvas
    private var y = margin

    private fun paint(size: Float, bold: Boolean = false, color: Int = 0xFF000000.toInt()) = Paint().apply {
        isAntiAlias = true
        textSize = size
        this.color = color
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun newPage() {
        if (pageNo > 0) doc.finishPage(page)
        pageNo++
        page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
        canvas = page.canvas
        y = margin
    }

    private fun ensure(h: Float) { if (y + h > pageH - margin) newPage() }

    private fun fit(text: String, p: Paint, maxW: Float): String {
        if (p.measureText(text) <= maxW) return text
        var t = text
        while (t.isNotEmpty() && p.measureText("$t…") > maxW) t = t.dropLast(1)
        return "$t…"
    }

    /** Wraps long free text so it never runs off the page. */
    private fun wrap(text: String, p: Paint, maxW: Float): List<String> {
        val lines = mutableListOf<String>()
        var cur = ""
        for (word in text.split(" ")) {
            val next = if (cur.isEmpty()) word else "$cur $word"
            if (p.measureText(next) <= maxW) cur = next else { if (cur.isNotEmpty()) lines.add(cur); cur = word }
        }
        if (cur.isNotEmpty()) lines.add(cur)
        return lines
    }

    fun render(out: OutputStream, blocks: List<PdfBlock>) {
        newPage()
        for (b in blocks) {
            when (b) {
                is PdfBlock.Heading -> {
                    val p = paint(b.size, bold = true)
                    ensure(b.size + 12)
                    y += b.size
                    canvas.drawText(fit(b.text, p, contentW), margin, y, p)
                    y += 10
                }
                is PdfBlock.Line -> {
                    val p = paint(10.5f, b.bold)
                    for (l in wrap(b.text, p, contentW)) {
                        ensure(16f)
                        y += 13
                        canvas.drawText(l, margin, y, p)
                        y += 3
                    }
                }
                PdfBlock.Gap -> y += 10
                is PdfBlock.Grid -> drawGrid(b)
            }
        }
        doc.finishPage(page)
        doc.writeTo(out)
        doc.close()
    }

    private fun drawGrid(g: PdfBlock.Grid) {
        val sum = g.weights.sum()
        val widths = g.weights.map { it / sum * contentW }
        val textP = paint(9f)
        val boldP = paint(9f, bold = true)
        val headP = paint(9f, bold = true, color = 0xFFFFFFFF.toInt())
        val fill = Paint().apply { style = Paint.Style.FILL }
        val grid = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 0.5f; color = 0xFFB0BEC5.toInt() }

        fun drawRow(cells: List<String>, p: Paint, bg: Int?) {
            if (bg != null) { fill.color = bg; canvas.drawRect(margin, y, margin + contentW, y + rowH, fill) }
            var x = margin
            for ((i, w) in widths.withIndex()) {
                val t = fit(cells.getOrElse(i) { "" }, p, w - 8f)
                val tx = if (i in g.numericCols) x + w - 4f - p.measureText(t) else x + 4f
                canvas.drawText(t, tx, y + rowH - 6f, p)
                canvas.drawRect(x, y, x + w, y + rowH, grid)
                x += w
            }
            y += rowH
        }

        fun header() = drawRow(g.headers, headP, g.headerColor)

        if (g.title != null) {
            val tp = paint(11f, bold = true, color = g.headerColor)
            ensure(18f + rowH * 3)
            y += 14
            canvas.drawText(fit(g.title, tp, contentW), margin, y, tp)
            y += 5
        } else ensure(rowH * 3)
        header()
        for ((idx, r) in g.rows.withIndex()) {
            if (y + rowH > pageH - margin) { newPage(); header() }
            drawRow(r, textP, if (idx % 2 == 1) 0xFFF5F7F8.toInt() else null)
        }
        if (g.total != null) {
            if (y + rowH > pageH - margin) { newPage(); header() }
            drawRow(g.total, boldP, 0xFFE0E6E9.toInt())
        }
        y += 4
    }
}
