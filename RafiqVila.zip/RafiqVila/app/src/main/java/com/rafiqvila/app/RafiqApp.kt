package com.rafiqvila.app

import android.app.Application
import com.rafiqvila.app.backup.BackupManager
import com.rafiqvila.app.data.AppDatabase
import com.rafiqvila.app.data.Repository

class RafiqApp : Application() {
    val database by lazy { AppDatabase.get(this) }
    val repository by lazy { Repository(database) }
    val backupManager by lazy { BackupManager(this, database) }
}
