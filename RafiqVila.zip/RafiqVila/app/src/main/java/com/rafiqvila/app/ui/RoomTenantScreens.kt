package com.rafiqvila.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.rafiqvila.app.data.RoomEntity
import com.rafiqvila.app.data.TenantEntity
import com.rafiqvila.app.domain.*

@Composable
private fun RowMenu(items: List<Pair<String, () -> Unit>>) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.Default.MoreVert, contentDescription = "মেনু") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            items.forEach { (label, action) ->
                DropdownMenuItem(text = { Text(label) }, onClick = { open = false; action() })
            }
        }
    }
}

@Composable
fun RoomsScreen(vm: MainViewModel, nav: NavController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val dash by vm.dashboard.collectAsStateWithLifecycle()
    val pid by vm.selectedProperty.collectAsStateWithLifecycle()
    val period by vm.period.collectAsStateWithLifecycle()
    var showAdd by remember { mutableStateOf(false) }
    var editRoom by remember { mutableStateOf<RoomEntity?>(null) }
    var assignRoom by remember { mutableStateOf<Long?>(null) }
    var vacate by remember { mutableStateOf<TenantEntity?>(null) }
    var remove by remember { mutableStateOf<RoomEntity?>(null) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 88.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { PropertyDropdown(data.properties, pid, { vm.selectedProperty.value = it }) }
            item { Text("${Period.labelBn(period)} • মোট ${dash.roomRows.size}টি রুম", style = MaterialTheme.typography.bodyMedium) }
            if (dash.roomRows.isEmpty()) item { EmptyNote("কোনো রুম নেই। নিচের + বোতামে রুম যোগ করুন।") }
            items(dash.roomRows, key = { it.room.id }) { row ->
                Card(Modifier.fillMaxWidth().clickable { nav.navigate("history/${row.room.id}") }) {
                    Row(Modifier.padding(start = 14.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("রুম ${row.room.number}  •  ${row.propertyName}", fontWeight = FontWeight.Bold)
                            Text("মাসিক ভাড়া: ${Money.taka(row.room.monthlyRent)}", style = MaterialTheme.typography.bodySmall)
                            Text(row.tenant?.let { "ভাড়াটিয়া: ${it.name}" } ?: "খালি রুম", style = MaterialTheme.typography.bodySmall)
                            row.summary?.let { Text(balanceText(it.closingBalance), style = MaterialTheme.typography.bodySmall) }
                            if (row.room.notes.isNotBlank()) Text(row.room.notes, style = MaterialTheme.typography.bodySmall)
                        }
                        RowMenu(buildList {
                            add("সম্পাদনা / ভাড়া পরিবর্তন" to { editRoom = row.room })
                            add("পেমেন্ট হিস্ট্রি" to { nav.navigate("history/${row.room.id}") })
                            if (row.tenant == null) add("ভাড়াটিয়া নিয়োগ" to { assignRoom = row.room.id })
                            else add("রুম খালি করুন" to { vacate = row.tenant })
                            add("রুম বাতিল (আর্কাইভ)" to { remove = row.room })
                        })
                    }
                }
            }
        }
        FloatingActionButton(onClick = { showAdd = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)) {
            Icon(Icons.Default.Add, contentDescription = "রুম যোগ")
        }
    }

    if (showAdd) RoomFormDialog(vm, data, null, pid) { showAdd = false }
    editRoom?.let { r -> RoomFormDialog(vm, data, r, null) { editRoom = null } }
    assignRoom?.let { id -> TenantFormDialog(vm, data, id, null) { assignRoom = null } }
    vacate?.let { t ->
        ConfirmDialog(
            "রুম খালি করবেন?", "${t.name} বের হয়ে যাবেন। তাঁর আগের সব হিসাব ও বকেয়া/অগ্রিম সংরক্ষিত থাকবে।",
            onConfirm = { vm.moveOut(t.id) }, onDismiss = { vacate = null }
        )
    }
    remove?.let { r ->
        ConfirmDialog(
            "রুম বাতিল করবেন?", "রুম ${r.number} সক্রিয় তালিকা থেকে সরবে, কিন্তু সব আর্থিক ইতিহাস থাকবে। ভাড়াটিয়া থাকলে বাতিল হবে না।",
            onConfirm = { vm.deactivateRoom(r.id) }, onDismiss = { remove = null }
        )
    }
}

@Composable
fun TenantsScreen(vm: MainViewModel, nav: NavController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val pid by vm.selectedProperty.collectAsStateWithLifecycle()
    var showFormer by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<TenantEntity?>(null) }
    var change by remember { mutableStateOf<TenantEntity?>(null) }
    var moveOut by remember { mutableStateOf<TenantEntity?>(null) }
    val roomById = data.rooms.associateBy { it.id }
    val list = data.tenants
        .filter { (pid == null || it.propertyId == pid) && (showFormer || it.active) }
        .sortedWith(compareByDescending<TenantEntity> { it.active }.thenBy { it.name })

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 88.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { PropertyDropdown(data.properties, pid, { vm.selectedProperty.value = it }) }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("সাবেক ভাড়াটিয়াও দেখান", Modifier.weight(1f))
                    Switch(checked = showFormer, onCheckedChange = { showFormer = it })
                }
            }
            if (list.isEmpty()) item { EmptyNote("কোনো ভাড়াটিয়া নেই") }
            items(list, key = { it.id }) { t ->
                val bal = Accounting.lifetimeBalance(t.id, data.charges.filter { it.tenantId == t.id }, data.adjustments, data.payments)
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 14.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(t.name + if (t.active) "" else " (সাবেক)", fontWeight = FontWeight.Bold)
                            Text("${propName(data, t.propertyId)} • রুম ${roomById[t.roomId]?.number.orEmpty()}", style = MaterialTheme.typography.bodySmall)
                            Text(if (t.phone.isBlank()) "মোবাইল নম্বর নেই" else t.phone, style = MaterialTheme.typography.bodySmall)
                            Text(
                                "শুরু: ${Dhaka.formatDate(t.startEpochDay)}" + (t.endEpochDay?.let { "  শেষ: ${Dhaka.formatDate(it)}" } ?: ""),
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(balanceText(bal), style = MaterialTheme.typography.bodySmall)
                        }
                        RowMenu(buildList {
                            add("সম্পাদনা" to { edit = t })
                            add("পেমেন্ট হিস্ট্রি" to { nav.navigate("history/${t.roomId}") })
                            if (t.active) {
                                add("রুম পরিবর্তন" to { change = t })
                                add("বের করুন (নিষ্ক্রিয়)" to { moveOut = t })
                            }
                        })
                    }
                }
            }
        }
        FloatingActionButton(onClick = { showAdd = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)) {
            Icon(Icons.Default.Add, contentDescription = "ভাড়াটিয়া যোগ")
        }
    }

    if (showAdd) TenantFormDialog(vm, data, null, null) { showAdd = false }
    edit?.let { t -> TenantFormDialog(vm, data, null, t) { edit = null } }
    change?.let { t -> ChangeRoomDialog(vm, data, t) { change = null } }
    moveOut?.let { t ->
        ConfirmDialog(
            "ভাড়াটিয়াকে বের করবেন?", "${t.name} নিষ্ক্রিয় হবেন ও রুম খালি হবে। আগের সব হিসাব সংরক্ষিত থাকবে; নতুন ভাড়াটিয়া এই হিসাব পাবেন না।",
            onConfirm = { vm.moveOut(t.id) }, onDismiss = { moveOut = null }
        )
    }
}
