package com.rafiqvila.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** Billing periods are stored as an Int in the form yyyymm (e.g. 202610 = October 2026). */

@Entity(tableName = "properties")
data class PropertyEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val address: String = "",
    val active: Boolean = true
)

@Entity(
    tableName = "rooms",
    foreignKeys = [ForeignKey(entity = PropertyEntity::class, parentColumns = ["id"], childColumns = ["propertyId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index(value = ["propertyId", "number"], unique = true)]
)
data class RoomEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val propertyId: Long,
    val number: String,
    val monthlyRent: Long,
    val active: Boolean = true,
    val notes: String = ""
)

/** One tenancy = one person in one room. Ledger rows hang off the tenancy, so a new tenant never inherits old balances. */
@Entity(
    tableName = "tenants",
    foreignKeys = [
        ForeignKey(entity = PropertyEntity::class, parentColumns = ["id"], childColumns = ["propertyId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = RoomEntity::class, parentColumns = ["id"], childColumns = ["roomId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index("propertyId"), Index("roomId")]
)
data class TenantEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val propertyId: Long,
    val roomId: Long,
    val startEpochDay: Long,
    val endEpochDay: Long? = null,
    val active: Boolean = true,
    val notes: String = ""
)

@Entity(
    tableName = "rent_charges",
    foreignKeys = [ForeignKey(entity = TenantEntity::class, parentColumns = ["id"], childColumns = ["tenantId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index(value = ["tenantId", "period"], unique = true)]
)
data class RentChargeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tenantId: Long,
    val period: Int,
    val amount: Long,
    val createdAt: Long
)

@Entity(
    tableName = "payments",
    foreignKeys = [ForeignKey(entity = TenantEntity::class, parentColumns = ["id"], childColumns = ["tenantId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("tenantId"), Index("period")]
)
data class PaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tenantId: Long,
    val period: Int,
    val amount: Long,
    val paidEpochDay: Long,
    val note: String = "",
    val createdAt: Long,
    val voided: Boolean = false,
    val voidReason: String = "",
    /** 0 = no SMS prepared, 1 = messaging app opened (sending/delivery is NOT verified). */
    val smsStatus: Int = 0
)

/** Signed correction: positive increases what the tenant owes, negative reduces it. */
@Entity(
    tableName = "financial_adjustments",
    foreignKeys = [ForeignKey(entity = TenantEntity::class, parentColumns = ["id"], childColumns = ["tenantId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("tenantId")]
)
data class FinancialAdjustmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tenantId: Long,
    val period: Int,
    val amount: Long,
    val reason: String,
    val createdAt: Long
)

@Entity(tableName = "audit_log")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val action: String,
    val entityType: String,
    val entityId: Long,
    val details: String
)

@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey val settingKey: String,
    val settingValue: String
)
