package com.rafiqvila.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rafiqvila.app.data.SavedPayment
import com.rafiqvila.app.domain.*
import com.rafiqvila.app.sms.SmsLauncher

@Composable
fun RentEntryScreen(vm: MainViewModel) {
    val data by vm.data.collectAsStateWithLifecycle()
    val period by vm.period.collectAsStateWithLifecycle()
    val globalPid by vm.selectedProperty.collectAsStateWithLifecycle()
    val saved by vm.savedPayment.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var propertyChoice by remember { mutableStateOf<Long?>(null) }
    var roomChoice by remember { mutableStateOf<Long?>(null) }
    var tenantChoice by remember { mutableStateOf<Long?>(null) }
    var amountText by remember { mutableStateOf("") }
    var payDay by remember { mutableStateOf(Dhaka.todayEpochDay()) }
    var note by remember { mutableStateOf("") }
    var showAdjust by remember { mutableStateOf(false) }
    var phoneDialogFor by remember { mutableStateOf<SavedPayment?>(null) }

    val propertyId = propertyChoice ?: globalPid ?: data.properties.firstOrNull { it.active }?.id
    val rooms = data.rooms.filter { it.active && it.propertyId == propertyId }
    val room = rooms.firstOrNull { it.id == roomChoice }
    val activeByRoom = data.tenants.filter { it.active }.associateBy { it.roomId }
    val tenancies = if (room == null) emptyList() else data.tenants.filter { it.roomId == room.id }.sortedByDescending { it.active }
    val tenant = tenancies.firstOrNull { it.id == tenantChoice } ?: tenancies.firstOrNull()
    val summary = tenant?.let { Accounting.summarize(it.id, period, period, data.charges, data.adjustments, data.payments) }

    fun launchSms(s: SavedPayment, phone: String) {
        val body = SmsMessage.build(s.propertyName, s.period, s.room.number, s.rent, s.paidNow, s.due, s.advance)
        val err = SmsLauncher.open(context, phone, body)
        if (err == null) vm.markSmsOpened(s.paymentId) else vm.say(err)
    }

    fun trySms(s: SavedPayment) {
        val raw = data.tenants.firstOrNull { it.id == s.tenant.id }?.phone ?: s.tenant.phone
        val phone = PhoneValidator.normalize(raw)
        if (phone == null) phoneDialogFor = s else launchSms(s, phone)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        saved?.let { s ->
            val smsStatus = data.payments.firstOrNull { it.id == s.paymentId }?.smsStatus ?: 0
            Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFE8F5E9))) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("✔ পেমেন্ট সংরক্ষিত হয়েছে", fontWeight = FontWeight.Bold)
                    KV("${s.propertyName} • রুম ${s.room.number}", Period.labelBn(s.period))
                    KV("এই পেমেন্ট", Money.taka(s.paidNow), bold = true)
                    KV("বাকি (বকেয়া)", Money.taka(s.due))
                    KV("অগ্রিম", Money.taka(s.advance))
                    Button(onClick = { trySms(s) }, modifier = Modifier.fillMaxWidth()) { Text("Send Rent SMS") }
                    Text(
                        if (smsStatus == 1) "মেসেজ অ্যাপ খোলা হয়েছে — পাঠানো/পৌঁছানো নিশ্চিত নয়। মেসেজ অ্যাপে নিজে Send চাপুন।"
                        else "মেসেজ এখনও প্রস্তুত করা হয়নি",
                        style = MaterialTheme.typography.bodySmall
                    )
                    TextButton(onClick = { vm.savedPayment.value = null }) { Text("বন্ধ করুন") }
                }
            }
        }

        PropertyDropdown(data.properties, propertyId, { propertyChoice = it; roomChoice = null; tenantChoice = null }, includeAll = false)
        PeriodSelector(period) { vm.period.value = it }
        DropdownSelector(
            "রুম",
            room?.let { "রুম ${it.number}" } ?: "রুম নির্বাচন করুন",
            rooms.map { r -> r.id to "রুম ${r.number} — ${activeByRoom[r.id]?.name ?: "খালি"}" },
            { roomChoice = it; tenantChoice = null; amountText = "" },
            Modifier.fillMaxWidth()
        )
        if (tenancies.size > 1) {
            DropdownSelector(
                "ভাড়াটিয়া",
                tenant?.name.orEmpty(),
                tenancies.map { it.id to it.name + if (it.active) "" else " (সাবেক)" },
                { tenantChoice = it },
                Modifier.fillMaxWidth()
            )
        }
        if (room != null && tenant == null) Text("এই রুমে কোনো ভাড়াটিয়া নেই। আগে ভাড়াটিয়া যোগ করুন।", color = MaterialTheme.colorScheme.error)

        if (room != null && tenant != null && summary != null) {
            Card {
                Column(Modifier.padding(14.dp)) {
                    KV("বাড়ি", propName(data, room.propertyId))
                    KV("রুম", room.number)
                    KV("ভাড়াটিয়া", tenant.name + if (tenant.active) "" else " (সাবেক)")
                    KV("মাস", Period.labelBn(period))
                    KV("মাসিক ভাড়া (বর্তমান)", Money.taka(room.monthlyRent))
                    HorizontalDivider(Modifier.padding(vertical = 6.dp))
                    KV("আগের ব্যালেন্স", balanceText(summary.previousBalance))
                    KV("এ মাসের ভাড়া চার্জ", Money.taka(summary.rentCharge))
                    if (summary.otherCharges != 0L) KV("অন্যান্য চার্জ/সমন্বয়", Money.taka(summary.otherCharges))
                    KV("এ মাসে এ পর্যন্ত জমা", Money.taka(summary.paid))
                    HorizontalDivider(Modifier.padding(vertical = 6.dp))
                    KV("বাকি (বকেয়া)", Money.taka(summary.due), bold = true)
                    KV("অগ্রিম", Money.taka(summary.advance), bold = true)
                }
            }
            TextButton(onClick = { showAdjust = true }) { Text("সমন্বয় / অন্যান্য চার্জ যোগ করুন") }

            MoneyField(amountText, { amountText = it }, "প্রাপ্ত টাকা")
            val preview = Money.parse(amountText)
            if (preview != null && preview > 0) {
                val after = summary.closingBalance - preview
                Text("এই পেমেন্টের পর: ${balanceText(after)}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
            }
            DateField("পেমেন্টের তারিখ", payDay, { payDay = it })
            OutlinedTextField(note, { note = it }, label = { Text("নোট (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth())
            Button(
                onClick = {
                    val amt = Money.parse(amountText)
                    if (amt == null || amt <= 0) vm.say("সঠিক টাকার পরিমাণ লিখুন")
                    else vm.savePayment(tenant.id, period, amt, payDay, note) { amountText = ""; note = "" }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("পেমেন্ট সংরক্ষণ করুন") }
        }
    }

    if (showAdjust && tenant != null) {
        AdjustmentDialog(onDismiss = { showAdjust = false }) { amount, reason, onErr ->
            vm.addAdjustment(tenant.id, period, amount, reason, { showAdjust = false }, onErr)
        }
    }

    phoneDialogFor?.let { s ->
        var text by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { phoneDialogFor = null },
            title = { Text("মোবাইল নম্বর প্রয়োজন") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ভাড়াটিয়ার মোবাইল নম্বর নেই বা সঠিক নয়। সঠিক নম্বর দিন (উদাহরণ: 01712345678)।")
                    OutlinedTextField(
                        text, { text = it }, label = { Text("মোবাইল নম্বর") }, singleLine = true,
                        isError = err != null, supportingText = { err?.let { e -> Text(e) } },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.updatePhone(s.tenant.id, text, { err = it }) { normalized ->
                        phoneDialogFor = null
                        launchSms(s, normalized)
                    }
                }) { Text("সংরক্ষণ ও মেসেজ খুলুন") }
            },
            dismissButton = { TextButton(onClick = { phoneDialogFor = null }) { Text("বাতিল") } }
        )
    }
}
