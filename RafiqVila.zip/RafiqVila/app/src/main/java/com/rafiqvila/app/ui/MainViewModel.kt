package com.rafiqvila.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rafiqvila.app.RafiqApp
import com.rafiqvila.app.data.AppError
import com.rafiqvila.app.data.AuditLogEntity
import com.rafiqvila.app.data.SavedPayment
import com.rafiqvila.app.domain.Accounting
import com.rafiqvila.app.domain.DashboardResult
import com.rafiqvila.app.domain.Dhaka
import com.rafiqvila.app.domain.Exports
import com.rafiqvila.app.domain.Filter
import com.rafiqvila.app.domain.LedgerData
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as RafiqApp
    val repo = app.repository
    private val backup = app.backupManager

    val selectedProperty = MutableStateFlow<Long?>(null)
    val period = MutableStateFlow(Dhaka.currentPeriod())
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val savedPayment = MutableStateFlow<SavedPayment?>(null)
    val lastBackup = MutableStateFlow<Long?>(null)
    val audit = MutableStateFlow<List<AuditLogEntity>>(emptyList())

    private val base = combine(repo.properties, repo.rooms, repo.tenants) { p, r, t -> Triple(p, r, t) }
    private val ledger = combine(repo.charges, repo.adjustments, repo.payments) { c, a, p -> Triple(c, a, p) }

    /** Every table is observed as a Flow, so all screens update automatically after any change. */
    val data: StateFlow<LedgerData> = combine(base, ledger) { b, l ->
        LedgerData(b.first, b.second, b.third, l.first, l.second, l.third)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, LedgerData())

    val dashboard: StateFlow<DashboardResult> = combine(data, selectedProperty, period) { d, pid, per ->
        Accounting.compute(d, Filter(propertyId = pid), per, per)
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, DashboardResult.EMPTY)

    init {
        // Creates any missing monthly rent charges at start-up and whenever the month selection changes.
        viewModelScope.launch {
            period.collect {
                try { repo.ensureCharges() } catch (e: CancellationException) { throw e } catch (e: Exception) { /* retried next time */ }
            }
        }
    }

    fun say(msg: String) { messages.tryEmit(msg) }

    private fun act(
        success: String? = null,
        onOk: () -> Unit = {},
        onError: ((String) -> Unit)? = null,
        block: suspend () -> Unit
    ) {
        viewModelScope.launch {
            try {
                block()
                success?.let { say(it) }
                onOk()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val msg = if (e is AppError) (e.message ?: "ত্রুটি") else "ত্রুটি হয়েছে: ${e.message}"
                if (onError != null) onError(msg) else say(msg)
            }
        }
    }

    // ---- properties / rooms / tenants ----
    fun addProperty(name: String, address: String, onOk: () -> Unit, onError: (String) -> Unit) =
        act("বাড়ি যোগ হয়েছে", onOk, onError) { repo.addProperty(name, address) }

    fun updateProperty(id: Long, name: String, address: String, onOk: () -> Unit, onError: (String) -> Unit) =
        act("বাড়ির তথ্য হালনাগাদ হয়েছে", onOk, onError) { repo.updateProperty(id, name, address) }

    fun addRoom(propertyId: Long, number: String, rent: Long, notes: String, onOk: () -> Unit, onError: (String) -> Unit) =
        act("রুম যোগ হয়েছে", onOk, onError) { repo.addRoom(propertyId, number, rent, notes) }

    fun updateRoom(id: Long, number: String, rent: Long, notes: String, onOk: () -> Unit, onError: (String) -> Unit) =
        act("রুম হালনাগাদ হয়েছে", onOk, onError) { repo.updateRoom(id, number, rent, notes) }

    fun deactivateRoom(id: Long) = act("রুম বাতিল করা হয়েছে (হিসাব সংরক্ষিত আছে)") { repo.deactivateRoom(id) }

    fun addTenant(name: String, phone: String, roomId: Long, start: Long, notes: String, onOk: () -> Unit, onError: (String) -> Unit) =
        act("ভাড়াটিয়া যোগ হয়েছে", onOk, onError) { repo.addTenant(name, phone, roomId, start, notes) }

    fun updateTenant(id: Long, name: String, phone: String, notes: String, onOk: () -> Unit, onError: (String) -> Unit) =
        act("ভাড়াটিয়ার তথ্য হালনাগাদ হয়েছে", onOk, onError) { repo.updateTenant(id, name, phone, notes) }

    fun moveOut(id: Long) = act("ভাড়াটিয়া বের হয়েছেন, রুম খালি") { repo.moveOut(id, Dhaka.todayEpochDay()) }

    fun changeRoom(id: Long, newRoomId: Long, day: Long, carry: Boolean, onOk: () -> Unit, onError: (String) -> Unit) =
        act("রুম পরিবর্তন হয়েছে", onOk, onError) { repo.changeRoom(id, newRoomId, day, carry) }

    // ---- payments ----
    fun savePayment(tenantId: Long, period: Int, amount: Long, day: Long, note: String, onOk: () -> Unit = {}) =
        act("পেমেন্ট সংরক্ষিত হয়েছে", onOk) { savedPayment.value = repo.savePayment(tenantId, period, amount, day, note) }

    fun voidPayment(id: Long, reason: String, onOk: () -> Unit, onError: (String) -> Unit) =
        act("পেমেন্ট বাতিল হয়েছে (রেকর্ড সংরক্ষিত)", onOk, onError) { repo.voidPayment(id, reason) }

    fun addAdjustment(tenantId: Long, period: Int, amount: Long, reason: String, onOk: () -> Unit, onError: (String) -> Unit) =
        act("সমন্বয় যোগ হয়েছে", onOk, onError) { repo.addAdjustment(tenantId, period, amount, reason) }

    fun markSmsOpened(paymentId: Long) = act { repo.markSmsOpened(paymentId) }

    fun updatePhone(tenantId: Long, phone: String, onError: (String) -> Unit, onDone: (String) -> Unit) {
        viewModelScope.launch {
            try { onDone(repo.updatePhone(tenantId, phone)) }
            catch (e: CancellationException) { throw e }
            catch (e: AppError) { onError(e.message ?: "ত্রুটি") }
            catch (e: Exception) { onError("ত্রুটি হয়েছে: ${e.message}") }
        }
    }

    // ---- backup / export ----
    fun refreshLastBackup() { viewModelScope.launch { lastBackup.value = repo.lastBackup() } }

    fun loadAudit() { viewModelScope.launch { audit.value = repo.recentAudit() } }

    fun exportBackup(uri: Uri) = act("ব্যাকআপ তৈরি হয়েছে") {
        backup.exportDatabase(uri)
        repo.setLastBackup(System.currentTimeMillis())
        lastBackup.value = repo.lastBackup()
    }

    fun restoreBackup(uri: Uri) = act("রিস্টোর সম্পন্ন") { backup.restore(uri) }

    fun exportLedgerCsv(uri: Uri) = act("CSV এক্সপোর্ট হয়েছে") { backup.writeText(uri, Exports.ledgerCsv(repo.snapshot())) }

    fun exportText(uri: Uri, text: String) = act("ফাইল তৈরি হয়েছে") { backup.writeText(uri, text) }

    fun exportPdf(uri: Uri, lines: List<String>) = act("PDF তৈরি হয়েছে") { backup.writePdf(uri, lines) }
}
