package com.rafiqvila.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PropertyDao {
    @Query("SELECT * FROM properties ORDER BY id")
    fun observeAll(): Flow<List<PropertyEntity>>

    @Query("SELECT * FROM properties WHERE id = :id")
    suspend fun get(id: Long): PropertyEntity?

    @Insert
    suspend fun insert(p: PropertyEntity): Long

    @Update
    suspend fun update(p: PropertyEntity)
}

@Dao
interface RoomDao {
    @Query("SELECT * FROM rooms ORDER BY propertyId, LENGTH(number), number")
    fun observeAll(): Flow<List<RoomEntity>>

    @Query("SELECT * FROM rooms WHERE id = :id")
    suspend fun get(id: Long): RoomEntity?

    @Query("SELECT * FROM rooms WHERE propertyId = :propertyId AND number = :number LIMIT 1")
    suspend fun find(propertyId: Long, number: String): RoomEntity?

    @Insert
    suspend fun insert(r: RoomEntity): Long

    @Update
    suspend fun update(r: RoomEntity)
}

@Dao
interface TenantDao {
    @Query("SELECT * FROM tenants ORDER BY id")
    fun observeAll(): Flow<List<TenantEntity>>

    @Query("SELECT * FROM tenants")
    suspend fun all(): List<TenantEntity>

    @Query("SELECT * FROM tenants WHERE id = :id")
    suspend fun get(id: Long): TenantEntity?

    @Query("SELECT * FROM tenants WHERE roomId = :roomId AND active = 1 LIMIT 1")
    suspend fun activeForRoom(roomId: Long): TenantEntity?

    @Insert
    suspend fun insert(t: TenantEntity): Long

    @Update
    suspend fun update(t: TenantEntity)
}

@Dao
interface LedgerDao {
    @Query("SELECT * FROM rent_charges")
    fun observeCharges(): Flow<List<RentChargeEntity>>

    @Query("SELECT * FROM financial_adjustments")
    fun observeAdjustments(): Flow<List<FinancialAdjustmentEntity>>

    @Query("SELECT * FROM payments")
    fun observePayments(): Flow<List<PaymentEntity>>

    @Query("SELECT * FROM rent_charges WHERE tenantId = :tenantId")
    suspend fun chargesFor(tenantId: Long): List<RentChargeEntity>

    @Query("SELECT * FROM financial_adjustments WHERE tenantId = :tenantId")
    suspend fun adjustmentsFor(tenantId: Long): List<FinancialAdjustmentEntity>

    @Query("SELECT * FROM payments WHERE tenantId = :tenantId")
    suspend fun paymentsFor(tenantId: Long): List<PaymentEntity>

    @Query("SELECT * FROM payments WHERE id = :id")
    suspend fun getPayment(id: Long): PaymentEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCharge(c: RentChargeEntity): Long

    @Insert
    suspend fun insertPayment(p: PaymentEntity): Long

    @Update
    suspend fun updatePayment(p: PaymentEntity)

    @Insert
    suspend fun insertAdjustment(a: FinancialAdjustmentEntity): Long

    @Insert
    suspend fun insertAudit(a: AuditLogEntity): Long

    @Query("SELECT * FROM audit_log ORDER BY id DESC LIMIT :limit")
    suspend fun recentAudit(limit: Int): List<AuditLogEntity>

    @Query("SELECT settingValue FROM app_settings WHERE settingKey = :key")
    suspend fun getSetting(key: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putSetting(s: AppSettingsEntity)
}
