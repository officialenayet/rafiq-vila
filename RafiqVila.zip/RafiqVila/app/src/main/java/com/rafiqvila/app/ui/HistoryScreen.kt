package com.rafiqvila.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rafiqvila.app.data.PaymentEntity
import com.rafiqvila.app.data.TenantEntity
import com.rafiqvila.app.domain.*

@Composable
fun HistoryScreen(vm: MainViewModel, roomId: Long) {
    val data by vm.data.collectAsStateWithLifecycle()
    val room = data.rooms.firstOrNull { it.id == roomId }
    val tenancies = data.tenants.filter { it.roomId == roomId }.sortedByDescending { it.startEpochDay }
    val ids = tenancies.map { it.id }.toSet()
    val periods = (data.charges.filter { it.tenantId in ids }.map { it.period } +
        data.payments.filter { it.tenantId in ids }.map { it.period } +
        data.adjustments.filter { it.tenantId in ids }.map { it.period }).distinct().sortedDescending()
    var monthFilter by remember { mutableStateOf<Int?>(null) }
    var voidTarget by remember { mutableStateOf<PaymentEntity?>(null) }
    var adjustFor by remember { mutableStateOf<TenantEntity?>(null) }
    var sms by remember { mutableStateOf<SmsRequest?>(null) }
    var exportFor by remember { mutableStateOf<TenantEntity?>(null) }
    val period by vm.period.collectAsStateWithLifecycle()
    val roomNumber = room?.number.orEmpty()
    val propertyName = propName(data, room?.propertyId ?: 0)
    val csvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri: Uri? ->
        val t = exportFor
        if (uri != null && t != null) vm.exportText(uri, Exports.tenantHistoryCsv(t, roomNumber, propertyName, Accounting.history(t.id, data)))
    }
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri: Uri? ->
        val t = exportFor
        if (uri != null && t != null) vm.exportPdf(uri, Exports.tenantHistoryLines(t, roomNumber, propertyName, Accounting.history(t.id, data)))
    }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("${propName(data, room?.propertyId ?: 0)} • রুম ${room?.number.orEmpty()}", style = MaterialTheme.typography.titleMedium)
            Text("বর্তমান মাসিক ভাড়া: ${Money.taka(room?.monthlyRent ?: 0)} (পুরনো মাসের ভাড়া অপরিবর্তিত)", style = MaterialTheme.typography.bodySmall)
        }
        item {
            val options: List<Pair<Int?, String>> = listOf<Pair<Int?, String>>(null to "সব মাস") + periods.map { it to Period.labelBn(it) }
            DropdownSelector("মাস ফিল্টার", monthFilter?.let { Period.labelBn(it) } ?: "সব মাস", options, { monthFilter = it }, Modifier.fillMaxWidth())
        }
        if (tenancies.isEmpty()) item { EmptyNote("এই রুমে এখনো কোনো ভাড়াটিয়ার ইতিহাস নেই") }
        tenancies.forEach { t ->
            item(key = "t${t.id}") {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(t.name + if (t.active) " (বর্তমান)" else " (সাবেক)", fontWeight = FontWeight.Bold)
                        Text(
                            "থাকার সময়: ${Dhaka.formatDate(t.startEpochDay)} — " + (t.endEpochDay?.let { Dhaka.formatDate(it) } ?: "এখনও"),
                            style = MaterialTheme.typography.bodySmall
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(onClick = { adjustFor = t }) { Text("সমন্বয়") }
                            if (t.active && room != null) TextButton(onClick = { sms = SmsRequest(t, room, monthFilter ?: period) }) { Text("SMS পাঠান") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(onClick = { exportFor = t; pdfLauncher.launch("history_${roomNumber}_${t.name}.pdf") }) { Text("হিস্ট্রি PDF ডাউনলোড") }
                            TextButton(onClick = { exportFor = t; csvLauncher.launch("history_${roomNumber}_${t.name}.csv") }) { Text("CSV") }
                        }
                    }
                }
            }
            val entries = Accounting.history(t.id, data).filter { monthFilter == null || it.period == monthFilter }.sortedByDescending { it.period }
            items(entries, key = { "e${t.id}-${it.period}" }) { e ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(Period.labelBn(e.period), fontWeight = FontWeight.Bold)
                        KV("আগের ব্যালেন্স", balanceText(e.summary.previousBalance))
                        KV("ভাড়া চার্জ", Money.taka(e.summary.rentCharge))
                        e.adjustments.forEach { a ->
                            KV("সমন্বয়: ${a.reason}", (if (a.amount > 0) "+" else "") + Money.taka(a.amount))
                        }
                        e.payments.forEach { p ->
                            Row(Modifier.fillMaxWidth()) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        "পেমেন্ট ${Dhaka.formatDate(p.paidEpochDay)}: ${Money.taka(p.amount)}" + if (p.voided) " (বাতিল: ${p.voidReason})" else "",
                                        style = MaterialTheme.typography.bodyMedium,
                                        textDecoration = if (p.voided) TextDecoration.LineThrough else null,
                                        color = if (p.voided) Color.Gray else Color.Unspecified
                                    )
                                    if (p.note.isNotBlank()) Text(p.note, style = MaterialTheme.typography.bodySmall)
                                    if (p.smsStatus == 1 && !p.voided) Text("মেসেজ অ্যাপ খোলা হয়েছে", style = MaterialTheme.typography.bodySmall)
                                }
                                if (!p.voided) TextButton(onClick = { voidTarget = p }) { Text("বাতিল") }
                            }
                        }
                        HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        KV("মোট জমা", Money.taka(e.summary.paid))
                        KV("বাকি (বকেয়া)", Money.taka(e.summary.due), bold = true)
                        KV("অগ্রিম", Money.taka(e.summary.advance), bold = true)
                    }
                }
            }
        }
    }

    SmsRequestHandler(vm, data, sms) { sms = null }
    adjustFor?.let { t ->
        val p = monthFilter ?: Dhaka.currentPeriod()
        AdjustmentDialog(onDismiss = { adjustFor = null }) { amount, reason, onErr ->
            vm.addAdjustment(t.id, p, amount, reason, { adjustFor = null }, onErr)
        }
    }
    voidTarget?.let { p ->
        var reason by remember { mutableStateOf("") }
        var error by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { voidTarget = null },
            title = { Text("পেমেন্ট বাতিল করবেন?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${Money.taka(p.amount)} — রেকর্ড মুছবে না, শুধু বাতিল চিহ্নিত হবে এবং পরের সব ব্যালেন্স নতুন করে হিসাব হবে।")
                    OutlinedTextField(reason, { reason = it }, label = { Text("কারণ (আবশ্যক)") }, modifier = Modifier.fillMaxWidth())
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.voidPayment(p.id, reason, { voidTarget = null }, { error = it }) }) { Text("বাতিল করুন") }
            },
            dismissButton = { TextButton(onClick = { voidTarget = null }) { Text("ফিরে যান") } }
        )
    }
}
