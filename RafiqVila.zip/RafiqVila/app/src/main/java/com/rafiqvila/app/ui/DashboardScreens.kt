package com.rafiqvila.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.rafiqvila.app.domain.*

private data class CardSpec(val label: String, val value: String, val route: String, val color: Color)

@Composable
fun DashboardScreen(vm: MainViewModel, nav: NavController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val dash by vm.dashboard.collectAsStateWithLifecycle()
    val pid by vm.selectedProperty.collectAsStateWithLifecycle()
    val period by vm.period.collectAsStateWithLifecycle()
    val t = dash.totals
    val cards = listOf(
        CardSpec("মোট পাওনা", Money.taka(t.toCollect), "toCollect", Color(0xFFFFF3E0)),
        CardSpec("আদায় হয়েছে", Money.taka(t.collected), "collected", Color(0xFFE8F5E9)),
        CardSpec("মোট বকেয়া", Money.taka(t.due), "due", Color(0xFFFFEBEE)),
        CardSpec("মোট অগ্রিম", Money.taka(t.advance), "advance", Color(0xFFE3F2FD)),
        CardSpec("মোট রুম", t.totalRooms.toString(), "rooms", Color(0xFFF3E5F5)),
        CardSpec("ভাড়া দেওয়া রুম", t.occupiedRooms.toString(), "occupied", Color(0xFFE0F2F1)),
        CardSpec("খালি রুম", t.emptyRooms.toString(), "empty", Color(0xFFFFFDE7))
    )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        PropertyDropdown(data.properties, pid, { vm.selectedProperty.value = it })
        PeriodSelector(period) { vm.period.value = it }
        cards.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEach { c -> StatCard(c.label, c.value, c.color, Modifier.weight(1f)) { nav.navigate("list/${c.route}") } }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Text(
            "পাওনা = আগের ব্যালেন্স + এ মাসের ভাড়া। আদায় = এ মাসে নেওয়া পেমেন্ট। বকেয়া ও অগ্রিম = এ মাস পর্যন্ত হিসাবের ফল। কার্ডে ট্যাপ করলে তালিকা দেখাবে।",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
fun DrillDownScreen(vm: MainViewModel, type: String) {
    val data by vm.data.collectAsStateWithLifecycle()
    val dash by vm.dashboard.collectAsStateWithLifecycle()
    val pid by vm.selectedProperty.collectAsStateWithLifecycle()
    val period by vm.period.collectAsStateWithLifecycle()
    val header = (data.properties.firstOrNull { it.id == pid }?.name ?: "সব বাড়ি") + " • " + Period.labelBn(period)
    val roomById = data.rooms.associateBy { it.id }
    val tenantById = data.tenants.associateBy { it.id }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text(header, style = MaterialTheme.typography.titleMedium) }
        when (type) {
            "collected" -> {
                if (dash.payments.isEmpty()) item { EmptyNote("এ মাসে কোনো পেমেন্ট নেই") }
                items(dash.payments, key = { it.id }) { p ->
                    val tn = tenantById[p.tenantId]
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            KV("${propName(data, tn?.propertyId ?: 0)} • রুম ${roomById[tn?.roomId]?.number.orEmpty()}", Money.taka(p.amount), bold = true)
                            Text("${tn?.name.orEmpty()} • ${Dhaka.formatDate(p.paidEpochDay)}", style = MaterialTheme.typography.bodySmall)
                            if (p.note.isNotBlank()) Text(p.note, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            "rooms", "occupied", "empty" -> {
                val rows = when (type) {
                    "occupied" -> dash.roomRows.filter { it.tenant != null }
                    "empty" -> dash.roomRows.filter { it.tenant == null }
                    else -> dash.roomRows
                }
                if (rows.isEmpty()) item { EmptyNote("কোনো রুম নেই") }
                items(rows, key = { it.room.id }) { r ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            KV("${r.propertyName} • রুম ${r.room.number}", Money.taka(r.room.monthlyRent), bold = true)
                            Text(r.tenant?.let { "ভাড়াটিয়া: ${it.name}  ${it.phone}" } ?: "খালি", style = MaterialTheme.typography.bodySmall)
                            r.summary?.let { Text(balanceText(it.closingBalance), style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
            }
            else -> {
                val rows = when (type) {
                    "due" -> dash.rows.filter { it.summary.due > 0 }
                    "advance" -> dash.rows.filter { it.summary.advance > 0 }
                    else -> dash.rows.filter { it.summary.toCollect > 0 }
                }
                if (rows.isEmpty()) item { EmptyNote("তালিকা খালি") }
                items(rows, key = { it.tenant.id }) { r ->
                    val amount = when (type) {
                        "due" -> r.summary.due
                        "advance" -> r.summary.advance
                        else -> r.summary.toCollect
                    }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            KV("${propName(data, r.tenant.propertyId)} • রুম ${r.room?.number.orEmpty()}", Money.taka(amount), bold = true)
                            Text(
                                r.tenant.name + if (!r.tenant.active) " (সাবেক ভাড়াটিয়া)" else "",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }
}
