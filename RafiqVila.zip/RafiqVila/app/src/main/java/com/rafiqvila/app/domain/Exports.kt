package com.rafiqvila.app.domain

import java.time.Instant
import java.time.LocalDate

object Exports {
    private fun esc(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
    private fun per(p: Int) = "%04d-%02d".format(Period.year(p), Period.month(p))
    private fun day(millis: Long) = Instant.ofEpochMilli(millis).atZone(Dhaka.zone).toLocalDate().toString()

    /** Complete financial ledger (charges, payments incl. voided, adjustments). Opens correctly in Excel. */
    fun ledgerCsv(data: LedgerData): String {
        val prop = data.properties.associate { it.id to it.name }
        val room = data.rooms.associateBy { it.id }
        val tenant = data.tenants.associateBy { it.id }
        fun who(tid: Long): List<String> {
            val t = tenant[tid]
            return listOf(prop[t?.propertyId].orEmpty(), room[t?.roomId]?.number.orEmpty(), t?.name.orEmpty())
        }
        val sb = StringBuilder("\uFEFF")
        sb.append("type,property,room,tenant,period,date,amount_taka,note\n")
        fun line(type: String, tid: Long, period: Int, date: String, amount: Long, note: String) {
            sb.append((listOf(type) + who(tid) + listOf(per(period), date, amount.toString(), note)).joinToString(",") { esc(it) }).append('\n')
        }
        data.charges.forEach { line("RENT_CHARGE", it.tenantId, it.period, day(it.createdAt), it.amount, "") }
        data.adjustments.forEach { line("ADJUSTMENT", it.tenantId, it.period, day(it.createdAt), it.amount, it.reason) }
        data.payments.forEach {
            line(if (it.voided) "VOIDED_PAYMENT" else "PAYMENT", it.tenantId, it.period,
                LocalDate.ofEpochDay(it.paidEpochDay).toString(), it.amount, if (it.voided) it.voidReason else it.note)
        }
        return sb.toString()
    }

    fun reportCsv(result: DashboardResult, propNames: Map<Long, String>): String {
        val sb = StringBuilder("\uFEFF")
        sb.append("property,room,tenant,previous_balance,rent_charged,other_charges,to_collect,collected,due,advance\n")
        result.rows.forEach { r ->
            val s = r.summary
            sb.append(listOf(
                propNames[r.tenant.propertyId].orEmpty(), r.room?.number.orEmpty(), r.tenant.name,
                s.previousBalance.toString(), s.rentCharge.toString(), s.otherCharges.toString(),
                s.toCollect.toString(), s.paid.toString(), s.due.toString(), s.advance.toString()
            ).joinToString(",") { esc(it) }).append('\n')
        }
        return sb.toString()
    }

    fun reportLines(title: String, result: DashboardResult, propNames: Map<Long, String>): List<String> {
        val t = result.totals
        val out = mutableListOf(
            "RAFIQ VILA - রিপোর্ট", title, "",
            "মোট ভাড়া চার্জ: ${Money.taka(t.rentCharged)}",
            "মোট পাওনা: ${Money.taka(t.toCollect)}",
            "মোট আদায়: ${Money.taka(t.collected)}",
            "মোট বকেয়া: ${Money.taka(t.due)}",
            "মোট অগ্রিম: ${Money.taka(t.advance)}",
            "মোট রুম: ${t.totalRooms}   ভাড়া দেওয়া: ${t.occupiedRooms}   খালি: ${t.emptyRooms}",
            ""
        )
        result.rows.forEach { r ->
            out.add("${propNames[r.tenant.propertyId].orEmpty()} - রুম ${r.room?.number.orEmpty()} - ${r.tenant.name}")
            out.add("   পাওনা ${Money.taka(r.summary.toCollect)} | আদায় ${Money.taka(r.summary.paid)} | বকেয়া ${Money.taka(r.summary.due)} | অগ্রিম ${Money.taka(r.summary.advance)}")
        }
        return out
    }

    /** Full payment history of one tenancy, with a running balance. */
    fun tenantHistoryCsv(tenant: com.rafiqvila.app.data.TenantEntity, roomNumber: String, propertyName: String, entries: List<HistoryEntry>): String {
        val sb = StringBuilder("\uFEFF")
        sb.append("property,room,tenant,period,type,date,amount_taka,balance_after,note\n")
        var bal = 0L
        fun row(period: Int, type: String, date: String, amount: Long, note: String) {
            sb.append(listOf(propertyName, roomNumber, tenant.name, per(period), type, date, amount.toString(), bal.toString(), note)
                .joinToString(",") { esc(it) }).append('\n')
        }
        for (e in entries) {
            bal += e.summary.rentCharge
            row(e.period, "RENT_CHARGE", "", e.summary.rentCharge, "")
            for (a in e.adjustments) { bal += a.amount; row(e.period, "ADJUSTMENT", day(a.createdAt), a.amount, a.reason) }
            for (p in e.payments) {
                if (!p.voided) bal -= p.amount
                row(e.period, if (p.voided) "VOIDED_PAYMENT" else "PAYMENT", LocalDate.ofEpochDay(p.paidEpochDay).toString(), p.amount,
                    if (p.voided) p.voidReason else p.note)
            }
        }
        return sb.toString()
    }

    fun tenantHistoryLines(tenant: com.rafiqvila.app.data.TenantEntity, roomNumber: String, propertyName: String, entries: List<HistoryEntry>): List<String> {
        val out = mutableListOf(
            "RAFIQ VILA - পেমেন্ট হিস্ট্রি",
            "$propertyName - রুম $roomNumber - ${tenant.name}",
            "থাকার সময়: ${Dhaka.formatDate(tenant.startEpochDay)} - " + (tenant.endEpochDay?.let { Dhaka.formatDate(it) } ?: "এখনও"),
            ""
        )
        for (e in entries.sortedBy { it.period }) {
            out.add("${Period.labelBn(e.period)}: আগের ব্যালেন্স ${Money.taka(e.summary.previousBalance)}, ভাড়া ${Money.taka(e.summary.rentCharge)}")
            e.adjustments.forEach { out.add("   সমন্বয় (${it.reason}): ${Money.taka(it.amount)}") }
            e.payments.forEach {
                out.add("   পেমেন্ট ${Dhaka.formatDate(it.paidEpochDay)}: ${Money.taka(it.amount)}" + if (it.voided) " (বাতিল)" else "")
            }
            out.add("   বাকি ${Money.taka(e.summary.due)} | অগ্রিম ${Money.taka(e.summary.advance)}")
        }
        return out
    }
}
