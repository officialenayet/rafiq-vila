package com.rafiqvila.app.domain

import java.time.Instant
import java.time.LocalDate

object Exports {
    private fun esc(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
    private fun per(p: Int) = "%04d-%02d".format(Period.year(p), Period.month(p))
    private fun day(millis: Long) = Instant.ofEpochMilli(millis).atZone(Dhaka.zone).toLocalDate().toString()

    /** Complete financial ledger (charges, payments incl. voided, adjustments). Opens correctly in Excel. */
    fun ledgerCsv(data: LedgerData): String {
        val prop = data.properties.associate { it.id to it.name }
        val room = data.rooms.associateBy { it.id }
        val tenant = data.tenants.associateBy { it.id }
        fun who(tid: Long): List<String> {
            val t = tenant[tid]
            return listOf(prop[t?.propertyId].orEmpty(), room[t?.roomId]?.number.orEmpty(), t?.name.orEmpty())
        }
        val sb = StringBuilder("\uFEFF")
        sb.append("type,property,room,tenant,period,date,amount_taka,note\n")
        fun line(type: String, tid: Long, period: Int, date: String, amount: Long, note: String) {
            sb.append((listOf(type) + who(tid) + listOf(per(period), date, amount.toString(), note)).joinToString(",") { esc(it) }).append('\n')
        }
        data.charges.forEach { line("RENT_CHARGE", it.tenantId, it.period, day(it.createdAt), it.amount, "") }
        data.adjustments.forEach { line("ADJUSTMENT", it.tenantId, it.period, day(it.createdAt), it.amount, it.reason) }
        data.payments.forEach {
            line(if (it.voided) "VOIDED_PAYMENT" else "PAYMENT", it.tenantId, it.period,
                LocalDate.ofEpochDay(it.paidEpochDay).toString(), it.amount, if (it.voided) it.voidReason else it.note)
        }
        return sb.toString()
    }

    fun reportCsv(result: DashboardResult, propNames: Map<Long, String>): String {
        val sb = StringBuilder("\uFEFF")
        sb.append("property,room,tenant,previous_balance,rent_charged,other_charges,to_collect,collected,due,advance\n")
        result.rows.forEach { r ->
            val s = r.summary
            sb.append(listOf(
                propNames[r.tenant.propertyId].orEmpty(), r.room?.number.orEmpty(), r.tenant.name,
                s.previousBalance.toString(), s.rentCharge.toString(), s.otherCharges.toString(),
                s.toCollect.toString(), s.paid.toString(), s.due.toString(), s.advance.toString()
            ).joinToString(",") { esc(it) }).append('\n')
        }
        return sb.toString()
    }

    /** Full payment history of one tenancy, with a running balance. */
    fun tenantHistoryCsv(tenant: com.rafiqvila.app.data.TenantEntity, roomNumber: String, propertyName: String, entries: List<HistoryEntry>): String {
        val sb = StringBuilder("\uFEFF")
        sb.append("property,room,tenant,period,type,date,amount_taka,balance_after,note\n")
        var bal = 0L
        fun row(period: Int, type: String, date: String, amount: Long, note: String) {
            sb.append(listOf(propertyName, roomNumber, tenant.name, per(period), type, date, amount.toString(), bal.toString(), note)
                .joinToString(",") { esc(it) }).append('\n')
        }
        for (e in entries) {
            bal += e.summary.rentCharge
            row(e.period, "RENT_CHARGE", "", e.summary.rentCharge, "")
            for (a in e.adjustments) { bal += a.amount; row(e.period, "ADJUSTMENT", day(a.createdAt), a.amount, a.reason) }
            for (p in e.payments) {
                if (!p.voided) bal -= p.amount
                row(e.period, if (p.voided) "VOIDED_PAYMENT" else "PAYMENT", LocalDate.ofEpochDay(p.paidEpochDay).toString(), p.amount,
                    if (p.voided) p.voidReason else p.note)
            }
        }
        return sb.toString()
    }

    // ---------------- PDF (table) builders ----------------
    private fun m(n: Long) = Money.taka(n)
    private val HEAD5 = listOf("মাস (Month)", "ভাড়া (Rent)", "জমা (Paid)", "বকেয়া (Due)", "অগ্রিম (Advance)")
    private val W5 = listOf(2.2f, 1.5f, 1.5f, 1.5f, 1.7f)

    /** Tenant payment history as tables: Month / Rent / Paid / Due / Advance, then a payments list. */
    fun tenantHistoryPdf(tenant: com.rafiqvila.app.data.TenantEntity, roomNumber: String, propertyName: String, entries: List<HistoryEntry>): List<PdfBlock> {
        val sorted = entries.sortedBy { it.period }
        val rows = sorted.map { e ->
            val s = e.summary
            listOf(Period.labelBn(e.period), m(s.rentCharge + s.otherCharges), m(s.paid), m(s.due), m(s.advance))
        }
        val last = sorted.lastOrNull()?.summary
        val total = listOf(
            "মোট", m(sorted.sumOf { it.summary.rentCharge + it.summary.otherCharges }), m(sorted.sumOf { it.summary.paid }),
            m(last?.due ?: 0L), m(last?.advance ?: 0L)
        )
        val payments = sorted.flatMap { it.payments }.sortedWith(compareBy({ it.paidEpochDay }, { it.id }))
        val payRows = payments.map {
            listOf(Dhaka.formatDate(it.paidEpochDay), Period.labelBn(it.period), m(it.amount), if (it.voided) "বাতিল: ${it.voidReason}" else it.note)
        }
        val out = mutableListOf<PdfBlock>(
            PdfBlock.Heading("RAFIQ VILA — পেমেন্ট হিস্ট্রি"),
            PdfBlock.Line("$propertyName • রুম $roomNumber", bold = true),
            PdfBlock.Line("ভাড়াটিয়া: ${tenant.name}" + if (tenant.phone.isNotBlank()) "   মোবাইল: ${tenant.phone}" else ""),
            PdfBlock.Line("থাকার সময়: ${Dhaka.formatDate(tenant.startEpochDay)} — " + (tenant.endEpochDay?.let { Dhaka.formatDate(it) } ?: "এখনও")),
            PdfBlock.Gap,
            PdfBlock.Grid("মাসভিত্তিক হিসাব", PdfColors.forIndex(0), HEAD5, rows, total, W5, setOf(1, 2, 3, 4)),
            PdfBlock.Line("বকেয়া/অগ্রিম আগের মাসের জের (carry-forward) সহ। ভাড়া = ভাড়া চার্জ ± সমন্বয়।")
        )
        if (payRows.isNotEmpty()) {
            out.add(PdfBlock.Gap)
            out.add(PdfBlock.Grid("পেমেন্টের তালিকা", PdfColors.forIndex(1),
                listOf("তারিখ (Date)", "মাস (Month)", "টাকা (Amount)", "নোট / অবস্থা"), payRows, null, listOf(1.6f, 1.9f, 1.6f, 3f), setOf(2)))
        }
        return out
    }

    private fun roomOrder(): Comparator<TenancyRow> = compareBy<TenancyRow>({ it.room?.number?.length ?: 0 }, { it.room?.number.orEmpty() })

    /**
     * Monthly or yearly report as tables. With "all properties" a combined summary table comes first and then
     * one table set per property, each with its own header colour.
     */
    fun reportPdf(data: LedgerData, filter: Filter, yearly: Boolean, period: Int): List<PdfBlock> {
        val year = Period.year(period)
        val from = if (yearly) Period.of(year, 1) else period
        val to = if (yearly) Period.of(year, 12) else period
        val title = if (yearly) "বার্ষিক রিপোর্ট — $year" else "মাসিক রিপোর্ট — ${Period.labelBn(period)}"
        val props = data.properties.filter { it.active && (filter.propertyId == null || it.id == filter.propertyId) }
        val results = props.map { it to Accounting.compute(data, filter.copy(propertyId = it.id), from, to) }

        val out = mutableListOf<PdfBlock>(
            PdfBlock.Heading("RAFIQ VILA — $title"),
            PdfBlock.Line("তৈরির সময়: ${Dhaka.formatDateTime(System.currentTimeMillis())} (Asia/Dhaka)")
        )
        fun rentOf(r: DashboardResult) = r.rows.sumOf { it.summary.rentCharge + it.summary.otherCharges }

        if (filter.propertyId == null && results.size > 1) {
            out.add(PdfBlock.Gap)
            out.add(PdfBlock.Grid(
                "সব বাড়ির সারাংশ", PdfColors.DARK,
                listOf("বাড়ি (Property)", "ভাড়া (Rent)", "জমা (Paid)", "বকেয়া (Due)", "অগ্রিম (Advance)"),
                results.map { (p, r) -> listOf(p.name, m(rentOf(r)), m(r.totals.collected), m(r.totals.due), m(r.totals.advance)) },
                listOf("মোট", m(results.sumOf { rentOf(it.second) }), m(results.sumOf { it.second.totals.collected }),
                    m(results.sumOf { it.second.totals.due }), m(results.sumOf { it.second.totals.advance })),
                listOf(2.4f, 1.5f, 1.5f, 1.5f, 1.7f), setOf(1, 2, 3, 4)
            ))
        }

        results.forEachIndexed { i, (p, r) ->
            val color = PdfColors.forIndex(i)
            val t = r.totals
            out.add(PdfBlock.Gap)
            out.add(PdfBlock.Line("${p.name}  —  মোট রুম ${t.totalRooms}, ভাড়া দেওয়া ${t.occupiedRooms}, খালি ${t.emptyRooms}", bold = true))

            if (yearly) {
                val months = (1..12).map { Period.of(year, it) }.filter { it <= Dhaka.currentPeriod() }
                val mrows = months.map { per ->
                    val mr = Accounting.compute(data, filter.copy(propertyId = p.id), per, per)
                    listOf(Period.labelBn(per), m(rentOf(mr)), m(mr.totals.collected), m(mr.totals.due), m(mr.totals.advance))
                }
                val lastMonth = months.lastOrNull()?.let { Accounting.compute(data, filter.copy(propertyId = p.id), it, it) }
                out.add(PdfBlock.Grid(
                    "${p.name} — মাসভিত্তিক", color, HEAD5, mrows,
                    listOf("মোট", m(rentOf(r)), m(t.collected), m(lastMonth?.totals?.due ?: t.due), m(lastMonth?.totals?.advance ?: t.advance)),
                    W5, setOf(1, 2, 3, 4)
                ))
                out.add(PdfBlock.Gap)
            }

            val roomRows = r.rows.sortedWith(roomOrder()).map {
                val s = it.summary
                listOf(it.room?.number.orEmpty(), it.tenant.name + if (it.tenant.active) "" else " (সাবেক)",
                    m(s.rentCharge + s.otherCharges), m(s.paid), m(s.due), m(s.advance))
            }
            out.add(PdfBlock.Grid(
                "${p.name} — রুমভিত্তিক" + if (yearly) " (বছর শেষ পর্যন্ত)" else "", color,
                listOf("রুম (Room)", "ভাড়াটিয়া (Tenant)", "ভাড়া (Rent)", "জমা (Paid)", "বকেয়া (Due)", "অগ্রিম (Advance)"),
                roomRows, listOf("মোট", "", m(rentOf(r)), m(t.collected), m(t.due), m(t.advance)),
                listOf(1.1f, 2.6f, 1.5f, 1.5f, 1.5f, 1.7f), setOf(2, 3, 4, 5)
            ))
        }
        out.add(PdfBlock.Gap)
        out.add(PdfBlock.Line("বকেয়া/অগ্রিম আগের মাসের জেরসহ। ভাড়া = ভাড়া চার্জ ± সমন্বয়।"))
        return out
    }
}
