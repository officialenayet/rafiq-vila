package com.rafiqvila.app.data

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.rafiqvila.app.domain.Dhaka
import com.rafiqvila.app.domain.PhoneValidator
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class RepositoryTest {
    private lateinit var ctx: Context
    private lateinit var db: AppDatabase
    private lateinit var repo: Repository
    private val dbName = "test_rafiq.db"

    @Before fun setUp() {
        ctx = ApplicationProvider.getApplicationContext()
        ctx.deleteDatabase(dbName)
        db = AppDatabase.create(ctx, dbName)
        repo = Repository(db)
    }

    @After fun tearDown() { db.close(); ctx.deleteDatabase(dbName) }

    private fun firstProperty() = runBlocking { repo.properties.first().first().id }

    @Test fun seedsThreeProperties() = runBlocking {
        assertEquals(listOf("RAFIQ VILA 1", "RAFIQ VILA 2", "RAFIQ VILA 3"), repo.properties.first().map { it.name })
    }

    @Test fun roomNumbersUniquePerPropertyOnly() = runBlocking {
        val props = repo.properties.first()
        repo.addRoom(props[0].id, "101", 5000, "")
        repo.addRoom(props[1].id, "101", 6000, "")
        try { repo.addRoom(props[0].id, "101", 5000, ""); fail() } catch (e: AppError) { }
    }

    @Test fun paymentFlowAndPartialPayments() = runBlocking {
        val pid = firstProperty()
        val room = repo.addRoom(pid, "101", 5000, "")
        val tid = repo.addTenant("Test Tenant", "01712345678", room, Dhaka.todayEpochDay(), "")
        val period = Dhaka.currentPeriod()
        val s1 = repo.savePayment(tid, period, 4000, Dhaka.todayEpochDay(), "")
        assertEquals(1000L, s1.due); assertEquals(0L, s1.advance)
        val s2 = repo.savePayment(tid, period, 2000, Dhaka.todayEpochDay(), "")
        assertEquals(0L, s2.due); assertEquals(1000L, s2.advance)
        assertEquals(2, repo.payments.first().size)
        assertEquals(1, repo.charges.first().size)   // no duplicate charge
        repo.ensureCharges(); repo.ensureCharges()
        assertEquals(1, repo.charges.first().size)
    }

    @Test fun rejectsInvalidInput() = runBlocking {
        val pid = firstProperty()
        val room = repo.addRoom(pid, "101", 5000, "")
        try { repo.addTenant("X", "123", room, Dhaka.todayEpochDay(), ""); fail() } catch (e: AppError) { }
        val tid = repo.addTenant("X", "", room, Dhaka.todayEpochDay(), "")
        try { repo.savePayment(tid, Dhaka.currentPeriod(), -5, Dhaka.todayEpochDay(), ""); fail() } catch (e: AppError) { }
        assertEquals("+8801712345678", repo.updatePhone(tid, "01712345678"))
    }

    @Test fun moveOutAndRoomChangeKeepHistory() = runBlocking {
        val pid = firstProperty()
        val r1 = repo.addRoom(pid, "101", 5000, "")
        val r2 = repo.addRoom(pid, "102", 6000, "")
        val t1 = repo.addTenant("A", "", r1, Dhaka.todayEpochDay(), "")
        repo.savePayment(t1, Dhaka.currentPeriod(), 3000, Dhaka.todayEpochDay(), "")
        val t2 = repo.changeRoom(t1, r2, Dhaka.todayEpochDay(), true)
        val tenants = repo.tenants.first()
        assertTrue(tenants.first { it.id == t1 }.endEpochDay != null)
        assertTrue(!tenants.first { it.id == t1 }.active)
        assertEquals(2, tenants.size)
        val data = repo.snapshot()
        val old = com.rafiqvila.app.domain.Accounting.lifetimeBalance(t1, data.charges, data.adjustments, data.payments)
        val new = com.rafiqvila.app.domain.Accounting.lifetimeBalance(t2, data.charges, data.adjustments, data.payments)
        assertEquals(0L, old); assertEquals(2000L, new)
        assertEquals(1, repo.payments.first().size)
    }

    @Test fun voidedPaymentIsKeptAndBalanceRecalculated() = runBlocking {
        val pid = firstProperty()
        val room = repo.addRoom(pid, "101", 5000, "")
        val tid = repo.addTenant("A", "", room, Dhaka.todayEpochDay(), "")
        val saved = repo.savePayment(tid, Dhaka.currentPeriod(), 5000, Dhaka.todayEpochDay(), "")
        repo.voidPayment(saved.paymentId, "ভুল এন্ট্রি")
        val data = repo.snapshot()
        assertEquals(1, data.payments.size)
        assertEquals(5000L, com.rafiqvila.app.domain.Accounting.lifetimeBalance(tid, data.charges, data.adjustments, data.payments))
        assertTrue(repo.recentAudit().any { it.action == "PAYMENT_VOIDED" })
    }

    @Test fun dataSurvivesRestart() = runBlocking {
        val pid = firstProperty()
        val room = repo.addRoom(pid, "201", 7000, "")
        repo.addTenant("Persist", "", room, Dhaka.todayEpochDay(), "")
        db.close()
        val db2 = AppDatabase.create(ctx, dbName)
        val repo2 = Repository(db2)
        assertEquals(1, repo2.rooms.first().size)
        assertEquals("Persist", repo2.tenants.first().first().name)
        db2.close()
        db = AppDatabase.create(ctx, dbName); repo = Repository(db)
    }

    @Test fun backupFileValidatesAndCorruptFileIsRejected() = runBlocking {
        val bm = com.rafiqvila.app.backup.BackupManager(ctx, db)
        db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close()
        val copy = File(ctx.cacheDir, "copy.db")
        ctx.getDatabasePath(dbName).copyTo(copy, overwrite = true)
        bm.validate(copy)
        val bad = File(ctx.cacheDir, "bad.db").apply { writeText("not a database") }
        try { bm.validate(bad); fail() } catch (e: AppError) { }
    }
}
