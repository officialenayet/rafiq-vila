package com.rafiqvila.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SmsTest {
    @Test fun buildsExactMessage() {
        val msg = SmsMessage.build("RAFIQ VILA 2", 202610, "201", 6000, 5000, 1000, 0)
        val expected = "RAFIQ VILA 2\nMonth: October 2026\nRoom: 201\nRent: ৳6,000\nPaid: ৳5,000\nDue: ৳1,000\nAdvance: ৳0\n\nThank you."
        assertEquals(expected, msg)
    }

    @Test fun acceptsValidNumbers() {
        assertEquals("+8801712345678", PhoneValidator.normalize("01712345678"))
        assertEquals("+8801712345678", PhoneValidator.normalize("+880 1712-345678"))
        assertEquals("+8801912345678", PhoneValidator.normalize("8801912345678"))
        assertEquals("+8801712345678", PhoneValidator.normalize("০১৭১২৩৪৫৬৭৮"))
    }

    @Test fun rejectsMissingOrInvalidNumbers() {
        assertNull(PhoneValidator.normalize(""))
        assertNull(PhoneValidator.normalize("12345"))
        assertNull(PhoneValidator.normalize("01212345678"))
        assertNull(PhoneValidator.normalize("0171234567"))
    }
}
