package com.rafiqvila.app.domain

import com.rafiqvila.app.data.*
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class AccountingTest {
    private fun charge(t: Long, p: Int, a: Long) = RentChargeEntity(tenantId = t, period = p, amount = a, createdAt = 0)
    private fun pay(t: Long, p: Int, a: Long, voided: Boolean = false) =
        PaymentEntity(tenantId = t, period = p, amount = a, paidEpochDay = 0, createdAt = 0, voided = voided)
    private fun adj(t: Long, p: Int, a: Long) =
        FinancialAdjustmentEntity(tenantId = t, period = p, amount = a, reason = "test", createdAt = 0)
    private fun sum(t: Long, p: Int, c: List<RentChargeEntity>, a: List<FinancialAdjustmentEntity>, pm: List<PaymentEntity>) =
        Accounting.summarize(t, p, p, c, a, pm)

    @Test fun dueCarriesForward() {
        val c = listOf(charge(1, 202609, 5000), charge(1, 202610, 5000))
        val p = listOf(pay(1, 202609, 4000), pay(1, 202610, 4000))
        val s = sum(1, 202610, c, emptyList(), p)
        assertEquals(1000L, s.previousBalance)
        assertEquals(2000L, s.due)
        assertEquals(0L, s.advance)
    }

    @Test fun advanceCarriesForwardAndIsConsumed() {
        val c = listOf(charge(1, 202609, 5000), charge(1, 202610, 5000))
        val p = listOf(pay(1, 202609, 7000), pay(1, 202610, 3000))
        assertEquals(2000L, sum(1, 202609, c, emptyList(), p).advance)
        val oct = sum(1, 202610, c, emptyList(), p)
        assertEquals(-2000L, oct.previousBalance)
        assertEquals(0L, oct.due)
        assertEquals(0L, oct.advance)
    }

    @Test fun overpaymentBecomesAdvance() {
        val s = sum(1, 202610, listOf(charge(1, 202610, 5000)), emptyList(), listOf(pay(1, 202610, 7000)))
        assertEquals(0L, s.due)
        assertEquals(2000L, s.advance)
    }

    @Test fun multiplePartialPaymentsInOneMonth() {
        val p = listOf(pay(1, 202610, 1000), pay(1, 202610, 1500), pay(1, 202610, 500))
        val s = sum(1, 202610, listOf(charge(1, 202610, 5000)), emptyList(), p)
        assertEquals(3000L, s.paid)
        assertEquals(2000L, s.due)
    }

    @Test fun adjustmentsChangeBalance() {
        val a = listOf(adj(1, 202610, 500), adj(1, 202610, -300))
        val s = sum(1, 202610, listOf(charge(1, 202610, 5000)), a, emptyList())
        assertEquals(200L, s.otherCharges)
        assertEquals(5200L, s.due)
    }

    @Test fun voidingOldPaymentRecalculatesLaterBalances() {
        val c = listOf(charge(1, 202609, 5000), charge(1, 202610, 5000))
        val ok = listOf(pay(1, 202609, 5000), pay(1, 202610, 5000))
        assertEquals(0L, sum(1, 202610, c, emptyList(), ok).due)
        val voided = listOf(pay(1, 202609, 5000, voided = true), pay(1, 202610, 5000))
        val s = sum(1, 202610, c, emptyList(), voided)
        assertEquals(5000L, s.previousBalance)
        assertEquals(5000L, s.due)
    }

    @Test fun newTenantInSameRoomDoesNotInheritBalance() {
        val c = listOf(charge(1, 202609, 5000), charge(2, 202610, 5000))
        val s = sum(2, 202610, c, emptyList(), emptyList())
        assertEquals(0L, s.previousBalance)
        assertEquals(5000L, s.due)
        assertEquals(5000L, sum(1, 202610, c, emptyList(), emptyList()).due)
    }

    @Test fun moveOutStopsCharging() {
        val start = LocalDate.of(2026, 3, 15).toEpochDay()
        val end = LocalDate.of(2026, 5, 10).toEpochDay()
        assertEquals(listOf(202604, 202605), Accounting.periodsToCharge(start, end, 202610, setOf(202603)))
    }

    @Test fun vacantPeriodsAreNotCharged() {
        val start = LocalDate.of(2026, 8, 1).toEpochDay()
        assertEquals(listOf(202608, 202609, 202610), Accounting.periodsToCharge(start, null, 202610, emptySet()))
        assertEquals(emptyList<Int>(), Accounting.periodsToCharge(start, null, 202607, emptySet()))
    }

    @Test fun yearBoundaryPeriods() {
        val start = LocalDate.of(2026, 11, 5).toEpochDay()
        assertEquals(listOf(202611, 202612, 202701), Accounting.periodsToCharge(start, null, 202701, emptySet()))
    }

    private fun sample(): LedgerData {
        val props = listOf(PropertyEntity(1, "A"), PropertyEntity(2, "B"))
        val rooms = listOf(
            RoomEntity(1, 1, "101", 5000), RoomEntity(2, 1, "102", 5000), RoomEntity(3, 2, "201", 6000)
        )
        val tenants = listOf(
            TenantEntity(id = 1, name = "T1", propertyId = 1, roomId = 1, startEpochDay = 0),
            TenantEntity(id = 2, name = "T2", propertyId = 2, roomId = 3, startEpochDay = 0)
        )
        return LedgerData(
            props, rooms, tenants,
            listOf(charge(1, 202610, 5000), charge(2, 202610, 6000)), emptyList(),
            listOf(pay(1, 202610, 4000), pay(2, 202610, 7000))
        )
    }

    @Test fun propertyWiseDashboardTotals() {
        val r1 = Accounting.compute(sample(), Filter(propertyId = 1), 202610, 202610).totals
        assertEquals(5000L, r1.toCollect); assertEquals(4000L, r1.collected)
        assertEquals(1000L, r1.due); assertEquals(0L, r1.advance)
        assertEquals(2, r1.totalRooms); assertEquals(1, r1.occupiedRooms); assertEquals(1, r1.emptyRooms)
        val r2 = Accounting.compute(sample(), Filter(propertyId = 2), 202610, 202610).totals
        assertEquals(0L, r2.due); assertEquals(1000L, r2.advance); assertEquals(7000L, r2.collected)
    }

    @Test fun allPropertiesCombinedWithoutDoubleCounting() {
        val all = Accounting.compute(sample(), Filter(), 202610, 202610)
        assertEquals(11000L, all.totals.toCollect)
        assertEquals(11000L, all.totals.collected)
        assertEquals(1000L, all.totals.due)
        assertEquals(1000L, all.totals.advance)
        assertEquals(3, all.totals.totalRooms)
        assertEquals(2, all.totals.occupiedRooms)
        assertEquals(1, all.totals.emptyRooms)
        assertEquals(2, all.payments.size)
    }

    @Test fun formatsMoney() {
        assertEquals("৳5,000", Money.taka(5000))
        assertEquals("12,34,567", Money.group(1234567))
        assertEquals("৳0", Money.taka(0))
        assertEquals(5000L, Money.parse("৫০০০"))
    }

    @Test fun tenantHistoryCsvHasRunningBalance() {
        val t = TenantEntity(id = 1, name = "T1", propertyId = 1, roomId = 1, startEpochDay = 0)
        val data = LedgerData(
            charges = listOf(charge(1, 202609, 5000), charge(1, 202610, 5000)),
            payments = listOf(pay(1, 202609, 4000), pay(1, 202610, 1000, voided = true))
        )
        val csv = Exports.tenantHistoryCsv(t, "101", "RAFIQ VILA 1", Accounting.history(1, data))
        val lines = csv.trim().split("\n")
        assertEquals(5, lines.size)
        assertEquals(true, lines[2].contains("\"PAYMENT\"") && lines[2].endsWith("\"4000\",\"1000\",\"\""))
        assertEquals(true, lines.last().contains("\"6000\""))
        assertEquals(true, Exports.tenantHistoryLines(t, "101", "RAFIQ VILA 1", Accounting.history(1, data)).size > 5)
    }
}
