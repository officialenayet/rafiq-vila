# RAFIQ VILA — ভাড়া ব্যবস্থাপনা (Native Android)

Kotlin · Jetpack Compose (Material 3) · Room · Coroutines/Flow · ViewModel. সম্পূর্ণ অফলাইন; কোনো WebView/PWA নেই।

## Build
- **GitHub Actions (no PC needed):** push this project (or the zip) to a GitHub repo → Actions → *Build APK*. The APK appears under **Releases** as `RAFIQ-VILA.apk`.
- **Android Studio:** open the folder, *Build → Build Bundle(s)/APK(s) → Build APK(s)* (variant `release`; it is signed with `app/keystore/rafiqvila.jks`).
- **Command line:** `gradle assembleRelease` (Gradle 8.9, JDK 17) → `app/build/outputs/apk/release/app-release.apk`.

minSdk 26, target/compile SDK 34. The keystore is fixed so every build can be installed **over** the previous one without losing data. Keep the repo private; keep a copy of the keystore.

## Architecture
`data/` Room entities, DAOs, `Repository` (all writes in `withTransaction`) · `domain/` pure Kotlin: `Accounting` engine, `Money`, `Period`, SMS text, CSV/report export · `ui/` Compose screens + `MainViewModel` · `sms/SmsLauncher` · `backup/BackupManager`.

Tables: properties, rooms, tenants (one row = one tenancy), rent_charges, payments, financial_adjustments, audit_log, app_settings. Billing period = `yyyymm` Int. Unique indexes: room number per property; one rent charge per tenancy per period. Foreign keys are RESTRICT, so history can never be cascaded away.

## Accounting rules
`balance = previous + rent + other charges − payments` (integer Taka). `>0` due, `0` paid, `<0` advance. Nothing stores a balance: it is always computed from the ledger, so correcting an old row automatically fixes every later month. Balances carry forward and never reset.
- Rent charges are generated automatically for every month a tenancy overlaps (start month → end month), up to the current month (Asia/Dhaka). Vacant months are never charged. A month in which a tenant starts or leaves is charged in full; use an adjustment to prorate.
- A room's rent change affects only charges created afterwards.
- A new tenant is a new tenancy → starts at zero. Room change closes the old tenancy; optional carry-over moves the balance with two offsetting adjustments. The move month is charged to the old room.
- Payments belong to the billing month chosen at entry. "আদায়" on the dashboard = payments for the selected month. Wrong payments are **voided** (kept, struck through, audited), never deleted.
- Dashboard: *পাওনা* = Σ max(previous + rent + other, 0); *বকেয়া/অগ্রিম* = Σ of positive/negative closing balances (advance is never netted against someone else's due). Each tenancy counts once, so "সব বাড়ি" has no double counting.

## SMS
`Intent.ACTION_SENDTO` with `smsto:<+88…>?body=<encoded text>` plus the `sms_body` extra. The intent is resolved first (`<queries>` declared); if no Messaging app exists an error is shown. **No SMS permission is requested.** The landlord reviews and presses Send. The app only records *"Messaging app opened"* — it cannot know whether the SMS was sent or delivered. Text containing ৳ is Unicode, so carriers split it into 70-character segments.

## Backup
Settings → full database backup via the system file picker (no storage permission), restore (validated: SQLite header, schema version, required tables, integrity check; a safety copy of current data is kept, then the app restarts), full-ledger CSV. The data lives only on the phone and does not sync between phones. `allowBackup=false` keeps the data out of cloud/device-transfer backups.

## Tests
`app/src/test`: accounting (carry-forward due/advance, partial & multiple payments, adjustments, void & recalculation, move-out, vacant periods, property & combined totals), SMS text and phone validation, Robolectric tests for persistence across restart, room/tenant changes, voiding, backup validation. Run: `gradle testDebugUnitTest`.
